/**
 * STREAMFINDER - Frontend Application Logic
 */

// Application State
const state = {
  currentCountry: 'GB',
  currentCountryFlag: '🇬🇧',
  currentCountryName: 'United Kingdom',
  currentType: 'all', // 'all', 'movie', 'tv'
  currentRating: '',
  currentGenre: '',
  currentGenreIsKeyword: false,
  selectedServices: new Set(),
  selectedCategories: new Set(),
  currentLanguage: '',
  currentYear: '',
  currentRuntime: '',
  searchQuery: '',
  searchDebounceTimer: null,
  catalogRequestId: 0,
  page: 1,
  totalPages: 1,
  watchlist: JSON.parse(localStorage.getItem('motn_watchlist') || '[]'),
  recentHistory: JSON.parse(localStorage.getItem('motn_recent_history') || '[]'),
  userRatings: JSON.parse(localStorage.getItem('motn_user_ratings') || '[]'),
  localMovieReviews: JSON.parse(localStorage.getItem('motn_movie_reviews') || '[]'),
  movieReviewsCache: new Map(),
  movieReviewSort: 'newest',
  currentDetailItem: null,
  backdropPreloadCache: new Map(),
  watchlistSort: 'recent',
  user: JSON.parse(localStorage.getItem('motn_user') || 'null'),
  countries: [],
  services: [],
  surpriseSeenIds: new Set(),
  surpriseLastResult: null,
  surpriseCandidateCache: new Map(),
  surpriseDetailsCache: new Map(),
  surpriseRequestController: null,
  surpriseRequestId: 0,
  collectionCache: new Map(),
  dashboardRecommendationsCache: new Map(),
  dashboardRecommendationsPending: new Map(),
  actorProfile: null,
  actorFilters: { genre: '', year: '', country: '', service: '', sort: 'newest' }
};

const SURPRISE_MOOD_MAP = {
  'feel-good': [35, 10751, 10749, 10402],
  dark: [80, 53, 27, 18],
  action: [28, 12, 10759],
  funny: [35, 16, 10751],
  romantic: [10749, 18, 35],
  mystery: [9648, 53, 80],
  scary: [27, 53, 9648],
  adventure: [12, 28, 14],
  'mind-bending': [878, 9648, 53],
  family: [10751, 16, 35]
};

const SURPRISE_TAG_MAP = {
  action: [28, 12, 10759],
  adventure: [12, 28, 14],
  comedy: [35, 16],
  drama: [18, 10749],
  fantasy: [14, 878],
  family: [10751, 16],
  mystery: [9648, 53, 80],
  romance: [10749, 18],
  scifi: [878, 9648],
  thriller: [53, 80, 9648]
};

// DOM Elements
const elements = {
  // Navigation & Header
  homeLogoBtn: document.getElementById('homeLogoBtn'),
  navAboutBtn: document.getElementById('navAboutBtn'),
  navCatalogsBtn: document.getElementById('navCatalogsBtn'),
  navApiBtn: document.getElementById('navApiBtn'),
  navDashboardBtn: document.getElementById('navDashboardBtn'),
  navWatchlistBtn: document.getElementById('navWatchlistBtn'),
  watchlistCount: document.getElementById('watchlistCount'),
  searchInput: document.getElementById('searchInput'),
  clearSearchBtn: document.getElementById('clearSearchBtn'),
  apiStatusBtn: document.getElementById('apiStatusBtn'),
  signUpBtn: document.getElementById('signUpBtn'),
  logInBtn: document.getElementById('logInBtn'),
  userProfileBadge: document.getElementById('userProfileBadge'),
  userAvatarLetter: document.getElementById('userAvatarLetter'),
  userNameLabel: document.getElementById('userNameLabel'),
  logoutBtn: document.getElementById('logoutBtn'),

  // Filters
  dropdownType: document.getElementById('dropdownType'),
  typeTrigger: document.getElementById('typeTrigger'),
  selectedTypeText: document.getElementById('selectedTypeText'),
  dropdownRating: document.getElementById('dropdownRating'),
  ratingTrigger: document.getElementById('ratingTrigger'),
  selectedRatingText: document.getElementById('selectedRatingText'),
  dropdownGenre: document.getElementById('dropdownGenre'),
  genreTrigger: document.getElementById('genreTrigger'),
  selectedGenreText: document.getElementById('selectedGenreText'),
  servicesList: document.getElementById('servicesList'),
  categoryFilters: document.getElementById('categoryFilters'),
  filterLanguage: document.getElementById('filterLanguage'),
  filterYear: document.getElementById('filterYear'),
  filterRuntime: document.getElementById('filterRuntime'),
  countryPickerBtn: document.getElementById('countryPickerBtn'),
  currentFlag: document.getElementById('currentFlag'),
  currentCountryCode: document.getElementById('currentCountryCode'),

  // Views & Content
  filterBanner: document.getElementById('filterBanner'),
  filterBannerText: document.getElementById('filterBannerText'),
  resetFiltersBtn: document.getElementById('resetFiltersBtn'),
  loadingIndicator: document.getElementById('loadingIndicator'),
  errorMessage: document.getElementById('errorMessage'),
  errorDescription: document.getElementById('errorDescription'),
  retryBtn: document.getElementById('retryBtn'),
  carouselsSection: document.getElementById('carouselsSection'),
  resultsGridSection: document.getElementById('resultsGridSection'),
  resultsGrid: document.getElementById('resultsGrid'),
  actorPage: document.getElementById('actorPage'),
  dashboardPage: document.getElementById('dashboardPage'),
  gridTitle: document.getElementById('gridTitle'),
  gridCount: document.getElementById('gridCount'),
  paginationControls: document.getElementById('paginationControls'),
  loadMoreBtn: document.getElementById('loadMoreBtn'),

  // Modals
  detailsModal: document.getElementById('detailsModal'),
  closeDetailsBtn: document.getElementById('closeDetailsBtn'),
  detailsContent: document.getElementById('detailsContent'),
  countryModal: document.getElementById('countryModal'),
  closeCountryBtn: document.getElementById('closeCountryBtn'),
  countrySearchInput: document.getElementById('countrySearchInput'),
  countriesGrid: document.getElementById('countriesGrid'),
  surpriseMeBtn: document.getElementById('surpriseMeBtn'),
  surpriseModal: document.getElementById('surpriseModal'),
  closeSurpriseBtn: document.getElementById('closeSurpriseBtn'),
  surpriseGenre: document.getElementById('surpriseGenre'),
  surpriseMood: document.getElementById('surpriseMood'),
  surpriseLanguage: document.getElementById('surpriseLanguage'),
  surpriseCountry: document.getElementById('surpriseCountry'),
  surpriseService: document.getElementById('surpriseService'),
  surpriseTag: document.getElementById('surpriseTag'),
  surpriseReleaseFrom: document.getElementById('surpriseReleaseFrom'),
  surpriseReleaseTo: document.getElementById('surpriseReleaseTo'),
  surpriseMinRating: document.getElementById('surpriseMinRating'),
  surpriseMaxRuntime: document.getElementById('surpriseMaxRuntime'),
  runSurpriseBtn: document.getElementById('runSurpriseBtn'),
  resetSurpriseBtn: document.getElementById('resetSurpriseBtn'),
  surpriseStatus: document.getElementById('surpriseStatus'),
  surpriseResult: document.getElementById('surpriseResult'),
  apiModal: document.getElementById('apiModal'),
  closeApiBtn: document.getElementById('closeApiBtn'),
  tmdbKeyPreviewText: document.getElementById('tmdbKeyPreviewText'),
  motnKeyPreviewText: document.getElementById('motnKeyPreviewText'),
  inputTmdbKey: document.getElementById('inputTmdbKey'),
  inputMotnKey: document.getElementById('inputMotnKey'),
  saveKeysBtn: document.getElementById('saveKeysBtn'),
  saveKeysStatus: document.getElementById('saveKeysStatus'),
  aboutModal: document.getElementById('aboutModal'),
  closeAboutBtn: document.getElementById('closeAboutBtn'),
  authModal: document.getElementById('authModal'),
  closeAuthBtn: document.getElementById('closeAuthBtn'),
  authForm: document.getElementById('authForm'),
  authEmail: document.getElementById('authEmail'),
  watchlistDrawer: document.getElementById('watchlistDrawer'),
  closeWatchlistBtn: document.getElementById('closeWatchlistBtn'),
  closeWatchlistBackdrop: document.getElementById('closeWatchlistBackdrop'),
  watchlistItemsContainer: document.getElementById('watchlistItemsContainer'),
  videoModal: document.getElementById('videoModal'),
  closeVideoBtn: document.getElementById('closeVideoBtn'),
  videoContainer: document.getElementById('videoContainer'),
  toast: document.getElementById('toast'),
  toastMsg: document.getElementById('toastMsg')
};

// =========================================================
// Initialization
// =========================================================
async function init() {
  setupEventListeners();
  populateSurpriseSelectors();
  updateWatchlistBadge();
  checkUserSession();
  await loadCountries();
  await loadServices();
  populateYearFilter();
  renderCategoryFilters();
  await loadAppConfig();
  const watchRoute = new URLSearchParams(window.location.search).get('watch');
  const watchMatch = watchRoute?.match(/^(movie|tv)\/(\d+)$/);
  const actorId = window.location.hash.match(/^#actor\/(\d+)$/)?.[1];
  const dashboardRoute = window.location.hash === '#my-streamfinder';
  if (watchMatch) {
    const sharedCountry = new URLSearchParams(window.location.search).get('country');
    const country = state.countries.find(item => item.code === sharedCountry);
    if (country) {
      state.currentCountry = country.code;
      state.currentCountryFlag = country.flag;
      state.currentCountryName = country.name;
      elements.currentFlag.textContent = country.flag;
      elements.currentCountryCode.textContent = country.code;
    }
    await openDetailsModal(watchMatch[1], watchMatch[2]);
  } else if (actorId) {
    await loadActorPage(actorId, false);
  } else if (dashboardRoute) {
    await openDashboard(false);
  } else {
    await refreshCatalog();
  }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

async function loadActorPage(actorId, navigate = true) {
  if (navigate) history.pushState({ actorId }, '', `${window.location.pathname}#actor/${actorId}`);
  state.actorFilters = { genre: '', year: '', country: '', service: '', sort: 'newest' };
  state.actorProfile = null;
  elements.filterBanner.classList.add('hidden');
  elements.loadingIndicator.classList.add('hidden');
  elements.errorMessage.classList.add('hidden');
  elements.carouselsSection.classList.add('hidden');
  elements.resultsGridSection.classList.add('hidden');
  elements.dashboardPage.classList.add('hidden');
  elements.actorPage.classList.remove('hidden');
  elements.actorPage.innerHTML = '<div class="loading-container"><div class="spinner"></div><p>Loading actor profile and filmography...</p></div>';
  window.scrollTo({ top: 0, behavior: 'smooth' });

  try {
    const response = await fetch(`/api/actors/${actorId}?country=${state.currentCountry}`);
    if (!response.ok) throw new Error('Actor profile not found');
    state.actorProfile = await response.json();
    renderActorPage();
  } catch (error) {
    console.error('Failed to load actor profile:', error);
    elements.actorPage.innerHTML = `
      <div class="error-container">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <h3>Unable to load this actor profile</h3>
        <p>Actor information is unavailable right now.</p>
        <button class="btn-primary" type="button" data-actor-back>Back to titles</button>
      </div>
    `;
  }
}

function getFilteredActorMovies() {
  const filters = state.actorFilters;
  let movies = state.actorProfile?.movies || [];
  if (filters.genre) movies = movies.filter(movie => movie.genres.some(genre => String(genre.id) === filters.genre));
  if (filters.year) movies = movies.filter(movie => String(movie.releaseYear) === filters.year);
  if (filters.country) movies = movies.filter(movie => movie.productionCountries?.includes(filters.country));
  if (filters.service) {
    const service = state.services.find(item => item.id === filters.service);
    const serviceName = (service?.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    movies = movies.filter(movie => movie.providers.some(provider =>
      provider.name.toLowerCase().replace(/[^a-z0-9]/g, '').includes(serviceName)
    ));
  }

  return [...movies].sort((a, b) => {
    if (filters.sort === 'oldest') return (a.releaseYear || 0) - (b.releaseYear || 0) || a.title.localeCompare(b.title);
    if (filters.sort === 'rating') return b.rating - a.rating || b.popularity - a.popularity;
    if (filters.sort === 'popular') return b.popularity - a.popularity;
    return (b.releaseYear || 0) - (a.releaseYear || 0) || a.title.localeCompare(b.title);
  });
}

function actorMovieCard(movie, compact = false) {
  const poster = movie.posterUrl || movie.backdropUrl;
  return `
    <button class="actor-movie-card ${compact ? 'compact' : ''}" type="button" data-movie-id="${movie.id}">
      <span class="actor-movie-poster">${poster ? `<img src="${escapeHtml(poster)}" alt="${escapeHtml(movie.title)} poster" loading="lazy" decoding="async">` : '<span class="actor-no-poster">No image</span>'}</span>
      <span class="actor-movie-info">
        <strong>${escapeHtml(movie.title)}</strong>
        <span>${escapeHtml(movie.character || 'Role not listed')} · ${escapeHtml(movie.releaseYear || 'Year unavailable')}</span>
        ${!compact ? `
          <span class="actor-movie-meta">${movie.rating ? `★ ${escapeHtml(movie.rating)}` : 'Rating unavailable'}${movie.genres.length ? ` · ${movie.genres.map(genre => escapeHtml(genre.name)).join(', ')}` : ''}</span>
          <span class="actor-movie-meta">Director: ${escapeHtml(movie.director || 'Not listed')}</span>
          <span class="actor-provider-list">${movie.providers.length ? movie.providers.slice(0, 4).map(provider => `<span class="actor-provider">${provider.logo ? `<img src="${escapeHtml(provider.logo)}" alt="">` : ''}${escapeHtml(provider.name)}</span>`).join('') : '<span>Streaming availability not listed</span>'}</span>
        ` : ''}
      </span>
    </button>
  `;
}

function renderActorPage() {
  const actor = state.actorProfile;
  if (!actor) return;
  const movies = getFilteredActorMovies();
  const years = [...new Set(actor.movies.map(movie => movie.releaseYear).filter(Boolean))].sort((a, b) => b - a);
  const genres = [...new Map(actor.movies.flatMap(movie => movie.genres).map(genre => [genre.id, genre])).values()]
    .sort((a, b) => a.name.localeCompare(b.name));
  const countries = [...new Set(actor.movies.flatMap(movie => movie.productionCountries || []))].sort();
  const timelineYears = [...new Set(movies.map(movie => movie.releaseYear).filter(Boolean))].sort((a, b) => a - b);
  const biography = actor.biography ? escapeHtml(actor.biography) : 'No biography is available for this person.';

  elements.actorPage.innerHTML = `
    <button class="actor-back-button" type="button" data-actor-back><i class="fa-solid fa-arrow-left"></i> Back to titles</button>
    <header class="actor-profile-header">
      <div class="actor-profile-photo">${actor.profileUrl ? `<img src="${escapeHtml(actor.profileUrl)}" alt="${escapeHtml(actor.name)}">` : '<span class="actor-photo-fallback"><i class="fa-solid fa-user"></i></span>'}</div>
      <div class="actor-profile-copy">
        <p class="actor-eyebrow">${escapeHtml(actor.knownForDepartment || 'Filmography')}</p>
        <h1>${escapeHtml(actor.name || 'Actor profile')}</h1>
        <p class="actor-biography">${biography}</p>
        <div class="actor-facts">
          ${actor.birthday ? `<span><strong>Born</strong> ${escapeHtml(actor.birthday)}</span>` : ''}
          ${actor.placeOfBirth ? `<span><strong>Place of birth</strong> ${escapeHtml(actor.placeOfBirth)}</span>` : ''}
          ${actor.professions.length ? `<span><strong>Known professions</strong> ${actor.professions.map(escapeHtml).join(', ')}</span>` : ''}
          ${actor.popularity !== null ? `<span><strong>TMDB popularity</strong> ${escapeHtml(actor.popularity)}</span>` : ''}
        </div>
        ${actor.socialLinks.length ? `<nav class="actor-social-links" aria-label="Official and social links">${actor.socialLinks.map(link => `<a href="${escapeHtml(link.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(link.label)} <i class="fa-solid fa-arrow-up-right-from-square"></i></a>`).join('')}</nav>` : ''}
      </div>
    </header>

    <section class="actor-section">
      <div class="actor-section-heading"><h2>Known For</h2></div>
      ${actor.knownFor.length ? `<div class="actor-known-for-grid">${actor.knownFor.map(movie => actorMovieCard(movie, true)).join('')}</div>` : '<p class="actor-empty">No notable movie credits are listed.</p>'}
    </section>

    <section class="actor-section">
      <div class="actor-section-heading"><h2>Career Timeline</h2><span>${movies.length} acting credits</span></div>
      ${timelineYears.length ? `<div class="actor-timeline">${timelineYears.map(year => `<div class="actor-timeline-year"><strong>${year}</strong><div>${movies.filter(movie => Number(movie.releaseYear) === year).map(movie => `<button type="button" data-movie-id="${movie.id}">${escapeHtml(movie.title)}${movie.character ? ` <span>as ${escapeHtml(movie.character)}</span>` : ''}</button>`).join('')}</div></div>`).join('')}</div>` : '<p class="actor-empty">No credits match the selected filters.</p>'}
    </section>

    <section class="actor-section actor-filmography">
      <div class="actor-section-heading"><h2>Movie Filmography</h2><span>${movies.length} movies</span></div>
      <div class="actor-filter-row">
        <label>Genre<select data-actor-filter="genre"><option value="">Any</option>${genres.map(genre => `<option value="${genre.id}" ${state.actorFilters.genre === String(genre.id) ? 'selected' : ''}>${escapeHtml(genre.name)}</option>`).join('')}</select></label>
        <label>Year<select data-actor-filter="year"><option value="">Any</option>${years.map(year => `<option value="${year}" ${state.actorFilters.year === String(year) ? 'selected' : ''}>${year}</option>`).join('')}</select></label>
        <label>Country<select data-actor-filter="country"><option value="">Any</option>${countries.map(country => `<option value="${country}" ${state.actorFilters.country === country ? 'selected' : ''}>${escapeHtml(country)}</option>`).join('')}</select></label>
        <label>Streaming platform<select data-actor-filter="service"><option value="">Any</option>${state.services.map(service => `<option value="${escapeHtml(service.id)}" ${state.actorFilters.service === service.id ? 'selected' : ''}>${escapeHtml(service.name)}</option>`).join('')}</select></label>
        <label>Sort<select data-actor-filter="sort"><option value="newest" ${state.actorFilters.sort === 'newest' ? 'selected' : ''}>Newest</option><option value="oldest" ${state.actorFilters.sort === 'oldest' ? 'selected' : ''}>Oldest</option><option value="rating" ${state.actorFilters.sort === 'rating' ? 'selected' : ''}>Highest rated</option><option value="popular" ${state.actorFilters.sort === 'popular' ? 'selected' : ''}>Most popular</option></select></label>
      </div>
      <div class="actor-filmography-list">${movies.length ? movies.map(movie => actorMovieCard(movie)).join('') : '<p class="actor-empty">No movie credits match these filters.</p>'}</div>
    </section>
  `;
}

function returnToCatalog() {
  history.pushState({}, '', window.location.pathname);
  elements.actorPage.classList.add('hidden');
  elements.dashboardPage.classList.add('hidden');
  elements.carouselsSection.classList.remove('hidden');
  refreshCatalog();
}

function syncRouteFromLocation() {
  if (window.location.hash === '#my-streamfinder') {
    openDashboard(false);
    return;
  }
  const actorId = window.location.hash.match(/^#actor\/(\d+)$/)?.[1];
  if (actorId) {
    loadActorPage(actorId, false);
    return;
  }
  const wasDashboardVisible = !elements.dashboardPage.classList.contains('hidden');
  elements.dashboardPage.classList.add('hidden');
  if (wasDashboardVisible || !elements.actorPage.classList.contains('hidden')) {
    elements.actorPage.classList.add('hidden');
    elements.carouselsSection.classList.remove('hidden');
    refreshCatalog();
  }
}

function getPersonalKey(item) {
  return `${item.showType || 'movie'}:${item.id}`;
}

function savePersonalData() {
  localStorage.setItem('motn_recent_history', JSON.stringify(state.recentHistory));
  localStorage.setItem('motn_user_ratings', JSON.stringify(state.userRatings));
}

function getItemProviderNames(item) {
  const options = item.streamingOptions || {};
  return [...new Set([
    ...(options.stream || []), ...(options.rent || []), ...(options.buy || []),
    ...(options.free || []), ...(item.providers || [])
  ].map(provider => provider.name).filter(Boolean))];
}

function recordRecentActivity(item, watched = false) {
  const key = getPersonalKey(item);
  const existing = state.recentHistory.find(entry => getPersonalKey(entry) === key) || {};
  const entry = {
    ...existing,
    id: item.id,
    showType: item.showType || 'movie',
    title: item.title || existing.title || 'Untitled',
    releaseYear: item.releaseYear || existing.releaseYear || '',
    rating: item.rating ?? existing.rating ?? 0,
    runtime: item.runtime || existing.runtime || null,
    runtimeMinutes: item.showType === 'tv' && item.runtime && item.episodesCount
      ? item.runtime * item.episodesCount
      : item.runtime || existing.runtimeMinutes || null,
    backdropUrl: item.backdropUrl || existing.backdropUrl || null,
    posterUrl: item.posterUrl || existing.posterUrl || null,
    genres: item.genres?.length ? item.genres.map(genre => ({ id: genre.id, name: genre.name })) : existing.genres || [],
    providerNames: getItemProviderNames(item).length ? getItemProviderNames(item) : existing.providerNames || [],
    recommendations: item.recommendations?.length ? item.recommendations.slice(0, 8).map(recommendation => ({
      id: recommendation.id,
      showType: recommendation.showType,
      title: recommendation.title,
      releaseYear: recommendation.releaseYear,
      rating: recommendation.rating,
      popularity: recommendation.popularity,
      genreIds: recommendation.genreIds || [],
      backdropUrl: recommendation.backdropUrl,
      posterUrl: recommendation.posterUrl
    })) : existing.recommendations || [],
    lastOpenedAt: new Date().toISOString(),
    watched: watched || existing.watched || false,
    watchedAt: watched ? new Date().toISOString() : existing.watchedAt || ''
  };
  state.recentHistory = [entry, ...state.recentHistory.filter(old => getPersonalKey(old) !== key)].slice(0, 100);
  savePersonalData();
  state.dashboardRecommendationsCache.clear();
}

function isItemMarkedWatched(item) {
  return state.recentHistory.some(entry => getPersonalKey(entry) === getPersonalKey(item) && entry.watched);
}

function savePersonalRating(item, rating) {
  const key = getPersonalKey(item);
  state.userRatings = state.userRatings.filter(entry => getPersonalKey(entry) !== key);
  if (rating) {
    state.userRatings.unshift({
      id: item.id,
      showType: item.showType || 'movie',
      title: item.title,
      releaseYear: item.releaseYear || '',
      overallRating: item.rating || 0,
      runtime: item.runtime || null,
      backdropUrl: item.backdropUrl || null,
      posterUrl: item.posterUrl || null,
      genres: item.genres || [],
      userRating: Number(rating),
      ratedAt: new Date().toISOString()
    });
  }
  savePersonalData();
  state.dashboardRecommendationsCache.clear();
  showToast(rating ? 'Your rating was saved on this device.' : 'Your rating was removed.');
  if (!elements.dashboardPage.classList.contains('hidden')) renderPersonalDashboard();
}

function markItemWatched(item) {
  recordRecentActivity(item, true);
  showToast(`Marked "${item.title}" as watched.`);
  const button = document.getElementById('modalMarkWatchedBtn');
  if (button) {
    button.classList.add('active');
    button.innerHTML = '<i class="fa-solid fa-check"></i> Watched';
  }
  if (!elements.dashboardPage.classList.contains('hidden')) renderPersonalDashboard();
}

function dashboardTitleCard(item, subtitle, actions = '') {
  const poster = item.backdropUrl || item.posterUrl || '';
  return `
    <article class="dashboard-title-card">
      <button class="dashboard-title-open" type="button" data-dashboard-open="${item.showType}:${item.id}" aria-label="Open ${escapeHtml(item.title)} details">
        <span class="dashboard-title-poster">${poster ? `<img src="${escapeHtml(poster)}" alt="${escapeHtml(item.title)} poster" loading="lazy" decoding="async">` : '<i class="fa-solid fa-film"></i>'}</span>
        <span class="dashboard-title-copy"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(subtitle)}</span></span>
      </button>
      ${actions ? `<div class="dashboard-title-actions">${actions}</div>` : ''}
    </article>
  `;
}

function countBy(values) {
  const counts = new Map();
  values.filter(Boolean).forEach(value => counts.set(value, (counts.get(value) || 0) + 1));
  return [...counts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])));
}

function renderPersonalDashboard() {
  const watched = state.recentHistory.filter(entry => entry.watched);
  const rated = [...state.userRatings].sort((a, b) => new Date(b.ratedAt) - new Date(a.ratedAt));
  const ratingsAverage = rated.length ? (rated.reduce((sum, entry) => sum + entry.userRating, 0) / rated.length).toFixed(1) : '—';
  const preferenceEntries = [...new Map([...state.recentHistory, ...rated].map(entry => [getPersonalKey(entry), entry])).values()];
  const genres = countBy(preferenceEntries.flatMap(entry => (entry.genres || []).map(genre => genre.name)));
  const platforms = countBy(preferenceEntries.flatMap(entry => entry.providerNames || []));
  const years = countBy(watched.map(entry => entry.releaseYear ? String(Math.floor(Number(entry.releaseYear) / 10) * 10) + 's' : ''));
  const totalMinutes = watched.reduce((sum, entry) => sum + (Number(entry.runtimeMinutes || entry.runtime) || 0), 0);
  const highestRated = [...rated].sort((a, b) => b.userRating - a.userRating)[0];
  const topGenres = genres.slice(0, 5);
  const topPlatforms = platforms.slice(0, 5);
  let watchlist = [...state.watchlist];
  if (state.watchlistSort === 'rating') watchlist.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  else if (state.watchlistSort === 'release') watchlist.sort((a, b) => (b.releaseYear || 0) - (a.releaseYear || 0));
  else if (state.watchlistSort === 'title') watchlist.sort((a, b) => a.title.localeCompare(b.title));
  else watchlist.sort((a, b) => new Date(b.addedAt || 0) - new Date(a.addedAt || 0));

  elements.dashboardPage.innerHTML = `
    <header class="dashboard-heading">
      <div><p class="dashboard-eyebrow">Your personal movie command center</p><h1>My StreamFinder</h1><p>Personal activity and ratings are stored only in this browser.</p></div>
    </header>
    <section class="dashboard-stats-grid" aria-label="Personal movie statistics">
      <div class="dashboard-stat"><span>Movies watched</span><strong>${watched.length}</strong></div>
      <div class="dashboard-stat"><span>Average rating</span><strong>${ratingsAverage}${rated.length ? ' / 10' : ''}</strong></div>
      <div class="dashboard-stat"><span>Total watch time</span><strong>${totalMinutes ? `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}m` : '—'}</strong></div>
      <div class="dashboard-stat"><span>Highest rated</span><strong>${highestRated ? escapeHtml(highestRated.title) : '—'}</strong></div>
    </section>

    <div class="dashboard-content-grid">
      <section class="dashboard-section dashboard-profile-section">
        <div class="dashboard-section-heading"><h2>Personal Movie Profile</h2></div>
        ${watched.length || rated.length ? `
          <div class="dashboard-profile-facts">
            <p><strong>Favorite genre</strong><span>${escapeHtml(topGenres[0]?.[0] || 'Not enough activity yet')}</span></p>
            <p><strong>Favorite platform</strong><span>${escapeHtml(topPlatforms[0]?.[0] || 'Not enough activity yet')}</span></p>
            <p><strong>Most watched decade</strong><span>${escapeHtml(years[0]?.[0] || 'Not enough activity yet')}</span></p>
            <p><strong>Top-rated title</strong><span>${highestRated ? `${escapeHtml(highestRated.title)} · ${highestRated.userRating}/10` : 'No personal ratings yet'}</span></p>
          </div>
          <div class="dashboard-taste-columns">
            <div><h3>Favorite genres</h3>${topGenres.length ? topGenres.map(([name, count]) => `<div class="taste-meter-row"><span>${escapeHtml(name)}</span><i><b style="width:${Math.max(8, count / topGenres[0][1] * 100)}%"></b></i><small>${count}</small></div>`).join('') : '<p class="dashboard-empty-inline">No genre data yet.</p>'}</div>
            <div><h3>Favorite platforms</h3>${topPlatforms.length ? topPlatforms.map(([name, count]) => `<div class="taste-meter-row"><span>${escapeHtml(name)}</span><i><b style="width:${Math.max(8, count / topPlatforms[0][1] * 100)}%"></b></i><small>${count}</small></div>`).join('') : '<p class="dashboard-empty-inline">No platform data yet.</p>'}</div>
          </div>
        ` : '<p class="dashboard-empty-inline">Your profile will take shape as you watch titles and save ratings.</p>'}
      </section>

      <section class="dashboard-section dashboard-recommendations-section">
        <div class="dashboard-section-heading"><h2>Recommendations</h2></div>
        <div id="dashboardRecommendations" class="dashboard-title-list"><p class="dashboard-empty-inline">Building recommendations from your watchlist and viewing activity...</p></div>
      </section>
    </div>

    <section class="dashboard-section">
      <div class="dashboard-section-heading"><h2>Watchlist <span>${watchlist.length}</span></h2><label class="dashboard-sort-control">Sort<select id="dashboardWatchlistSort"><option value="recent" ${state.watchlistSort === 'recent' ? 'selected' : ''}>Recently added</option><option value="rating" ${state.watchlistSort === 'rating' ? 'selected' : ''}>Rating</option><option value="release" ${state.watchlistSort === 'release' ? 'selected' : ''}>Release date</option><option value="title" ${state.watchlistSort === 'title' ? 'selected' : ''}>Title</option></select></label></div>
      <div class="dashboard-title-list">${watchlist.length ? watchlist.map(item => dashboardTitleCard(item, `${item.releaseYear || 'Year unavailable'} · ${item.rating ? `TMDB ${item.rating}/10` : 'No rating'} · ${item.category || 'To Watch'}`, `<label class="dashboard-category-control"><span>List</span><select data-watchlist-category="${item.id}" data-watchlist-type="${item.showType}"><option ${!item.category || item.category === 'To Watch' ? 'selected' : ''}>To Watch</option><option ${item.category === 'Favorites' ? 'selected' : ''}>Favorites</option><option ${item.category === 'Later' ? 'selected' : ''}>Later</option></select></label><button class="dashboard-icon-button" type="button" data-remove-watchlist="${item.id}" data-remove-type="${item.showType}" title="Remove from watchlist" aria-label="Remove ${escapeHtml(item.title)} from watchlist"><i class="fa-solid fa-trash-can"></i></button>`)).join('') : '<p class="dashboard-empty-inline">Your watchlist is empty. Save a title from its details or movie card.</p>'}</div>
    </section>

    <section class="dashboard-section">
      <div class="dashboard-section-heading"><h2>Recently Watched</h2><button id="clearHistoryBtn" class="dashboard-text-button" type="button" ${state.recentHistory.length ? '' : 'disabled'}>Clear History</button></div>
      <div class="dashboard-title-list">${state.recentHistory.length ? state.recentHistory.slice(0, 20).map(item => dashboardTitleCard(item, `${item.watched ? 'Watched' : 'Opened'} ${new Date(item.watchedAt || item.lastOpenedAt).toLocaleDateString()} · ${item.rating ? `TMDB ${item.rating}/10` : 'No overall rating'} · ${(item.providerNames || []).slice(0, 2).join(', ') || 'Availability not listed'}`, `<span class="dashboard-status-label">${item.watched ? 'Watched' : 'Viewed'}</span>`)).join('') : '<p class="dashboard-empty-inline">Opened or watched titles will appear here.</p>'}</div>
    </section>

    <section class="dashboard-section">
      <div class="dashboard-section-heading"><h2>My Ratings <span>${rated.length}</span></h2></div>
      <div class="dashboard-title-list">${rated.length ? rated.map(item => dashboardTitleCard(item, `Your ${item.userRating}/10 · TMDB ${item.overallRating || 'N/A'} · Rated ${new Date(item.ratedAt).toLocaleDateString()}`, `<label class="dashboard-rating-control"><span>Your rating</span><select data-personal-rating="${item.id}" data-rating-type="${item.showType}">${Array.from({ length: 10 }, (_, index) => index + 1).map(value => `<option value="${value}" ${value === item.userRating ? 'selected' : ''}>${value}/10</option>`).join('')}</select></label><button class="dashboard-icon-button" type="button" data-remove-rating="${item.id}" data-remove-type="${item.showType}" title="Remove rating" aria-label="Remove rating for ${escapeHtml(item.title)}"><i class="fa-solid fa-xmark"></i></button>`)).join('') : '<p class="dashboard-empty-inline">Your personal ratings will appear here after you rate a title.</p>'}</div>
    </section>
  `;
  loadDashboardRecommendations();
}

function openDashboard(navigate = true) {
  if (navigate) history.pushState({}, '', `${window.location.pathname}#my-streamfinder`);
  elements.filterBanner.classList.add('hidden');
  elements.loadingIndicator.classList.add('hidden');
  elements.errorMessage.classList.add('hidden');
  elements.carouselsSection.classList.add('hidden');
  elements.resultsGridSection.classList.add('hidden');
  elements.actorPage.classList.add('hidden');
  elements.dashboardPage.classList.remove('hidden');
  renderPersonalDashboard();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function loadDashboardRecommendations() {
  const mount = document.getElementById('dashboardRecommendations');
  if (!mount) return;
  const cacheKey = state.currentCountry;
  const renderItems = items => {
    const currentMount = document.getElementById('dashboardRecommendations');
    if (!currentMount) return;
    currentMount.innerHTML = items.length ? items.map(item => dashboardTitleCard(item, `${item.releaseYear || 'Year unavailable'} · TMDB ${item.rating || 'N/A'}${getItemProviderNames(item).length ? ` · ${getItemProviderNames(item).slice(0, 2).join(', ')}` : ''}`)).join('') : '<p class="dashboard-empty-inline">TMDB has no similar titles for your current personal activity yet.</p>';
  };
  if (state.dashboardRecommendationsCache.has(cacheKey)) {
    renderItems(state.dashboardRecommendationsCache.get(cacheKey));
    return;
  }
  const pendingRequest = state.dashboardRecommendationsPending.get(cacheKey);
  if (pendingRequest) {
    try {
      renderItems(await pendingRequest);
    } catch (error) {
      const currentMount = document.getElementById('dashboardRecommendations');
      if (currentMount) currentMount.innerHTML = '<p class="dashboard-empty-inline">Recommendations are temporarily unavailable.</p>';
    }
    return;
  }
  const watchedAndRated = [...state.recentHistory.filter(item => item.watched), ...state.userRatings];
  const candidates = [...state.userRatings, ...state.recentHistory, ...state.watchlist];
  const uniqueSeeds = [...new Map(candidates.map(item => [getPersonalKey(item), item])).values()].slice(0, 4);
  if (!uniqueSeeds.length) {
    mount.innerHTML = '<p class="dashboard-empty-inline">Add titles to your watchlist, open movie details, or rate a movie to get personal recommendations.</p>';
    return;
  }

  const request = (async () => {
    const seedDetails = await Promise.all(uniqueSeeds.map(async item => {
      if (item.recommendations?.length) return item;
      const response = await fetch(`/api/details/${item.showType}/${item.id}?country=${state.currentCountry}`);
      return response.ok ? response.json() : null;
    }));
    const preferredGenres = new Set(watchedAndRated.flatMap(item => (item.genres || []).map(genre => Number(genre.id))));
    const preferredPlatforms = new Set(watchedAndRated.flatMap(item => item.providerNames || []).map(name => name.toLowerCase()));
    const recommendationMap = new Map();
    seedDetails.filter(Boolean).forEach(seed => (seed.recommendations || []).forEach(item => {
      const key = getPersonalKey(item);
      if (key === getPersonalKey(seed) || state.recentHistory.some(viewed => getPersonalKey(viewed) === key) || state.watchlist.some(saved => getPersonalKey(saved) === key) || state.userRatings.some(ratedItem => getPersonalKey(ratedItem) === key)) return;
      const genreMatch = (item.genreIds || []).filter(id => preferredGenres.has(Number(id))).length;
      const sourcePlatforms = (seed.providerNames || []).filter(name => preferredPlatforms.has(name.toLowerCase())).length;
      const score = genreMatch * 3 + (Number(item.rating) || 0) + sourcePlatforms * 0.5 + (Number(item.popularity) || 0) / 100;
      const existing = recommendationMap.get(key);
      if (!existing || existing.score < score) recommendationMap.set(key, { item, score });
    }));

    const ranked = [...recommendationMap.values()].sort((a, b) => b.score - a.score).slice(0, 8);
    if (!ranked.length) return [];

    const enriched = await Promise.all(ranked.map(async ({ item }) => {
      const response = await fetch(`/api/details/${item.showType}/${item.id}?country=${state.currentCountry}`);
      return response.ok ? response.json() : item;
    }));
    const finalRecommendations = enriched.filter(Boolean).map(item => {
      const platforms = getItemProviderNames(item).map(name => name.toLowerCase());
      const platformMatch = platforms.some(name => preferredPlatforms.has(name));
      const genreMatch = (item.genres || []).filter(genre => preferredGenres.has(Number(genre.id))).length;
      return { item, score: genreMatch * 3 + (Number(item.rating) || 0) + (platformMatch ? 2 : 0) };
    }).sort((a, b) => b.score - a.score).slice(0, 6);
    return finalRecommendations.map(({ item }) => item);
  })();
  state.dashboardRecommendationsPending.set(cacheKey, request);
  try {
    const recommendations = await request;
    state.dashboardRecommendationsCache.set(cacheKey, recommendations);
    renderItems(recommendations);
  } catch (error) {
    console.error('Dashboard recommendations failed:', error);
    const currentMount = document.getElementById('dashboardRecommendations');
    if (currentMount) currentMount.innerHTML = '<p class="dashboard-empty-inline">Recommendations are temporarily unavailable.</p>';
  } finally {
    state.dashboardRecommendationsPending.delete(cacheKey);
  }
}

function populateSurpriseSelectors() {
  const genreOptions = [
    'Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy',
    'History', 'Horror', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western'
  ];

  const genreMap = {
    Action: 28,
    Adventure: 12,
    Animation: 16,
    Comedy: 35,
    Crime: 80,
    Documentary: 99,
    Drama: 18,
    Family: 10751,
    Fantasy: 14,
    History: 36,
    Horror: 27,
    Mystery: 9648,
    Romance: 10749,
    'Sci-Fi': 878,
    Thriller: 53,
    War: 10752,
    Western: 37
  };

  elements.surpriseGenre.innerHTML = '<option value="">Any</option>' + genreOptions.map(name => `<option value="${genreMap[name]}">${name}</option>`).join('');

  const countrySelect = elements.surpriseCountry;
  const currentCountryCode = state.currentCountry || 'GB';
  countrySelect.innerHTML = '<option value="">Any</option>' + state.countries.map(c => `<option value="${c.code}" ${c.code === currentCountryCode ? 'selected' : ''}>${c.flag} ${c.name} (${c.code})</option>`).join('');

  const servicesSelect = elements.surpriseService;
  servicesSelect.innerHTML = '<option value="">Any</option>' + state.services.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
}

function getSelectedSurpriseFilters() {
  return {
    genre: elements.surpriseGenre.value || '',
    mood: elements.surpriseMood.value || '',
    language: elements.surpriseLanguage.value || '',
    country: elements.surpriseCountry.value || state.currentCountry,
    service: elements.surpriseService.value || '',
    tag: elements.surpriseTag.value || '',
    releaseFrom: elements.surpriseReleaseFrom.value || '',
    releaseTo: elements.surpriseReleaseTo.value || '',
    minRating: elements.surpriseMinRating.value || '',
    maxRuntime: elements.surpriseMaxRuntime.value || ''
  };
}

function setSurpriseStatus(message, isEmpty = false) {
  elements.surpriseStatus.classList.remove('hidden');
  elements.surpriseStatus.textContent = message;
  elements.surpriseStatus.classList.toggle('empty', isEmpty);
}

function hideSurpriseStatus() {
  elements.surpriseStatus.classList.add('hidden');
}

function hideSurpriseResult() {
  elements.surpriseResult.classList.add('hidden');
  elements.surpriseResult.innerHTML = '';
}

function filterMatchesGenre(movieGenreIds, selectedGenre) {
  if (!selectedGenre) return true;
  const normalizedSelected = Number(selectedGenre);
  return (movieGenreIds || []).some(id => Number(id) === normalizedSelected);
}

function filterMatchesMood(movieGenreIds, selectedMood) {
  if (!selectedMood) return true;
  const moodGenres = SURPRISE_MOOD_MAP[selectedMood] || [];
  return (movieGenreIds || []).some(id => moodGenres.includes(Number(id)));
}

function filterMatchesTag(movieGenreIds, selectedTag) {
  if (!selectedTag) return true;
  const tagGenres = SURPRISE_TAG_MAP[selectedTag] || [];
  return (movieGenreIds || []).some(id => tagGenres.includes(Number(id)));
}

function matchesSurpriseFilters(movie, filters, allowUnknownRuntime = false) {
  if (!movie) return false;

  const releaseYear = Number(movie.releaseYear || 0);
  const rating = Number(movie.rating || 0);
  const runtime = Number(movie.runtime || 0);
  const genreIds = Array.isArray(movie.genres) ? movie.genres.map(g => Number(g.id)) : (movie.genreIds || []);

  if (filters.genre && !filterMatchesGenre(genreIds, filters.genre)) return false;
  if (filters.mood && !filterMatchesMood(genreIds, filters.mood)) return false;
  if (filters.tag && !filterMatchesTag(genreIds, filters.tag)) return false;
  if (filters.language && (movie.originalLanguage || '').toLowerCase() !== filters.language.toLowerCase()) return false;
  if (filters.releaseFrom && (!releaseYear || releaseYear < Number(filters.releaseFrom))) return false;
  if (filters.releaseTo && (!releaseYear || releaseYear > Number(filters.releaseTo))) return false;
  if (filters.minRating && rating < Number(filters.minRating)) return false;
  if (filters.maxRuntime && ((!runtime && !allowUnknownRuntime) || (runtime && runtime > Number(filters.maxRuntime)))) return false;

  return true;
}

function chooseUnseenMovie(candidates) {
  const unseen = candidates.filter(movie => !state.surpriseSeenIds.has(movie.id));
  if (unseen.length > 0) return unseen[Math.floor(Math.random() * unseen.length)];
  if (candidates.length > 0) return candidates[Math.floor(Math.random() * candidates.length)];
  return null;
}

async function runSurpriseSearch() {
  const filters = getSelectedSurpriseFilters();
  state.surpriseRequestController?.abort();
  const controller = new AbortController();
  state.surpriseRequestController = controller;
  const requestId = ++state.surpriseRequestId;
  hideSurpriseStatus();
  hideSurpriseResult();
  setSurpriseStatus('Finding a matching movie for you...');
  elements.runSurpriseBtn.disabled = true;

  const maxPages = 3;
  const triedIds = new Set();
  let foundSeenMatch = false;

  try {
    for (let page = 1; page <= maxPages; page += 1) {
      const pageResults = await loadSurpriseCandidates(filters, page, controller.signal);
      if (requestId !== state.surpriseRequestId) return;

      if (!pageResults.length) break;

      while (true) {
        const matchingCandidates = pageResults.filter(item =>
          item?.id && matchesSurpriseFilters(item, filters, true)
        );
        if (matchingCandidates.some(item => state.surpriseSeenIds.has(item.id))) foundSeenMatch = true;
        const candidates = matchingCandidates.filter(item =>
          !triedIds.has(item.id) && !state.surpriseSeenIds.has(item.id)
        );
        if (!candidates.length) break;

        const batchSize = filters.maxRuntime ? 4 : 1;
        const batch = [...candidates].sort(() => Math.random() - 0.5).slice(0, batchSize);
        batch.forEach(item => triedIds.add(item.id));
        const details = await Promise.all(batch.map(item =>
          loadSurpriseDetails(item.id, filters.country || state.currentCountry, controller.signal)
            .catch(error => {
              if (error.name !== 'AbortError') console.error('Failed to load surprise candidate:', error);
              return null;
            })
        ));
        if (requestId !== state.surpriseRequestId) return;

        const matching = details.filter(movie => movie && matchesSurpriseFilters(movie, filters));
        if (matching.length) {
          const winner = chooseUnseenMovie(matching);
          state.surpriseSeenIds.add(winner.id);
          state.surpriseLastResult = winner;
          renderSurpriseResult(winner);
          hideSurpriseStatus();
          return;
        }
      }
    }

    if (requestId === state.surpriseRequestId) {
      setSurpriseStatus(
        foundSeenMatch ? 'You have seen all matching movies in this session. Try relaxing one or two filters.' : 'No matching movies found. Try relaxing one or two filters to widen the search.',
        true
      );
    }
  } catch (error) {
    if (requestId !== state.surpriseRequestId || error.name === 'AbortError') return;
    console.error('Surprise search failed:', error);
    setSurpriseStatus('Something went wrong while finding your movie. Please try again.', true);
  } finally {
    if (requestId === state.surpriseRequestId) {
      elements.runSurpriseBtn.disabled = false;
      state.surpriseRequestController = null;
    }
  }
}

async function loadSurpriseCandidates(filters, page, signal) {
  const cacheKey = JSON.stringify(filters);
  let cachedPages = state.surpriseCandidateCache.get(cacheKey);
  if (!cachedPages) {
    cachedPages = new Map();
    state.surpriseCandidateCache.set(cacheKey, cachedPages);
    if (state.surpriseCandidateCache.size > 12) {
      state.surpriseCandidateCache.delete(state.surpriseCandidateCache.keys().next().value);
    }
  }
  if (cachedPages.has(page)) return cachedPages.get(page);

  const params = new URLSearchParams({
    type: 'movie',
    country: filters.country || state.currentCountry,
    page: String(page),
    sort: 'popularity.desc'
  });
  if (filters.service) params.set('service', filters.service);
  if (filters.genre) params.set('genre', filters.genre);
  if (filters.minRating) params.set('rating', filters.minRating);

  const response = await fetch(`/api/discover?${params.toString()}`, { signal });
  if (!response.ok) throw new Error('Failed to fetch discover results');
  const data = await response.json();
  const results = data.results || [];
  cachedPages.set(page, results);
  return results;
}

async function loadSurpriseDetails(movieId, country, signal) {
  const cacheKey = `${country}:${movieId}`;
  if (state.surpriseDetailsCache.has(cacheKey)) return state.surpriseDetailsCache.get(cacheKey);

  const response = await fetch(`/api/details/movie/${movieId}?country=${country}`, { signal });
  if (!response.ok) return null;
  const movie = await response.json();
  if (movie?.id) {
    state.surpriseDetailsCache.set(cacheKey, movie);
    if (state.surpriseDetailsCache.size > 150) {
      state.surpriseDetailsCache.delete(state.surpriseDetailsCache.keys().next().value);
    }
  }
  return movie;
}

function renderSurpriseResult(movie) {
  const inWatchlist = isItemInWatchlist(movie.id, movie.showType);
  const heroImage = movie.backdropUrl || movie.posterUrl || '';
  const providerList = [
    ...(movie.streamingOptions?.stream || []),
    ...(movie.streamingOptions?.rent || []),
    ...(movie.streamingOptions?.buy || [])
  ].slice(0, 6);

  elements.surpriseResult.classList.remove('hidden');
  elements.surpriseResult.innerHTML = `
    <div class="surprise-result-hero">
      ${heroImage ? `<img src="${heroImage}" alt="${movie.title}">` : ''}
    </div>
    <div class="surprise-result-body">
      <div class="surprise-result-meta">
        <span class="badge-rating-pill"><i class="fa-solid fa-star"></i> ${movie.rating || 'N/A'}</span>
        ${movie.releaseYear ? `<span class="badge-info-pill">${movie.releaseYear}</span>` : ''}
        ${movie.runtime ? `<span class="badge-info-pill">${movie.runtime} min</span>` : ''}
      </div>

      <h3 class="surprise-result-title">${movie.title}</h3>

      ${movie.genres && movie.genres.length ? `<div class="details-badges-row">${movie.genres.map(g => `<span class="badge-info-pill">${g.name}</span>`).join('')}</div>` : ''}

      <p class="surprise-result-overview">${movie.overview || 'No overview is available for this movie yet.'}</p>

      <div class="surprise-result-grid">
        <div class="surprise-stat">
          <span class="surprise-stat-label">Main Cast</span>
          <span class="surprise-stat-value">${(movie.cast || []).slice(0, 3).map(c => c.name).join(', ') || 'Not available'}</span>
        </div>
        <div class="surprise-stat">
          <span class="surprise-stat-label">Director</span>
          <span class="surprise-stat-value">${(movie.directors || [])[0]?.name || 'Not available'}</span>
        </div>
        <div class="surprise-stat">
          <span class="surprise-stat-label">Country</span>
          <span class="surprise-stat-value">${state.countries.find(c => c.code === (getSelectedSurpriseFilters().country || state.currentCountry))?.name || state.currentCountryName}</span>
        </div>
        <div class="surprise-stat">
          <span class="surprise-stat-label">Availability</span>
          <span class="surprise-stat-value">${providerList.length ? `${providerList.length} options` : 'No immediate match'}</span>
        </div>
      </div>

      <div class="surprise-provider-row">
        ${providerList.length ? providerList.map(p => `
          <span class="surprise-provider-chip">
            ${p.logo ? `<img src="${p.logo}" alt="${p.name}">` : ''}
            ${p.name}
          </span>
        `).join('') : '<span class="surprise-stat-value">No streaming providers available in this region.</span>'}
      </div>

      <div class="surprise-actions-row">
        ${movie.trailer ? `<button class="btn-play-trailer" type="button" id="surpriseTrailerBtn"><i class="fa-solid fa-play"></i> Trailer</button>` : ''}
        <button class="btn-watchlist-toggle ${inWatchlist ? 'active' : ''}" type="button" id="surpriseWatchlistBtn">
          <i class="fa-solid ${inWatchlist ? 'fa-check' : 'fa-bookmark'}"></i>
          <span>${inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}</span>
        </button>
        <button class="btn-view-details" type="button" id="surpriseDetailsBtn">View Details</button>
        <button class="btn-try-another" type="button" id="surpriseTryAnotherBtn">Try Another</button>
      </div>
    </div>
  `;

  const trailerBtn = document.getElementById('surpriseTrailerBtn');
  if (trailerBtn && movie.trailer) {
    trailerBtn.addEventListener('click', () => openVideoModal(movie.trailer.embedUrl));
  }

  const watchlistBtn = document.getElementById('surpriseWatchlistBtn');
  if (watchlistBtn) {
    watchlistBtn.addEventListener('click', () => {
      toggleWatchlist(movie);
      const active = isItemInWatchlist(movie.id, movie.showType);
      watchlistBtn.classList.toggle('active', active);
      watchlistBtn.innerHTML = `
        <i class="fa-solid ${active ? 'fa-check' : 'fa-bookmark'}"></i>
        <span>${active ? 'In Watchlist' : 'Add to Watchlist'}</span>
      `;
    });
  }

  const detailsBtn = document.getElementById('surpriseDetailsBtn');
  if (detailsBtn) {
    detailsBtn.addEventListener('click', () => {
      closeModal(elements.surpriseModal);
      openDetailsModal(movie.showType, movie.id);
    });
  }

  const tryAnotherBtn = document.getElementById('surpriseTryAnotherBtn');
  if (tryAnotherBtn) {
    tryAnotherBtn.addEventListener('click', () => runSurpriseSearch());
  }
}

// =========================================================
// Data Loading
// =========================================================

// Load Countries
async function loadCountries() {
  try {
    const res = await fetch('/api/countries');
    const data = await res.json();
    state.countries = data.countries || [];
    
    // Check saved country preference
    const savedCountry = localStorage.getItem('motn_country');
    if (savedCountry) {
      const match = state.countries.find(c => c.code === savedCountry);
      if (match) {
        state.currentCountry = match.code;
        state.currentCountryFlag = match.flag;
        state.currentCountryName = match.name;
        elements.currentFlag.textContent = match.flag;
        elements.currentCountryCode.textContent = match.code;
      }
    }
    renderCountryPickerGrid();
  } catch (err) {
    console.error('Failed to load countries:', err);
  }
}

// Load Streaming Services
async function loadServices() {
  try {
    const res = await fetch('/api/services');
    const data = await res.json();
    state.services = data.services || [];
    renderServicesBar();
  } catch (err) {
    console.error('Failed to load services:', err);
  }
}

// Load API Configuration
async function loadAppConfig() {
  try {
    const res = await fetch('/api/config');
    const data = await res.json();
    if (data.tmdbKeyPreview) elements.tmdbKeyPreviewText.textContent = `Key: ${data.tmdbKeyPreview}`;
    if (data.motnKeyPreview) elements.motnKeyPreviewText.textContent = `Key: ${data.motnKeyPreview}`;
  } catch (err) {
    console.error('Failed to load config:', err);
  }
}

// Refresh Catalog Based on Active State
async function refreshCatalog() {
  // If search query or any specific filter is active, use Discover Grid view
  const hasActiveFilters = state.searchQuery || state.currentRating || state.currentGenre || state.currentType !== 'all' ||
    state.selectedServices.size > 0 || state.selectedCategories.size > 0 || state.currentLanguage || state.currentYear || state.currentRuntime;
  
  if (state.searchQuery) {
    await performSearch();
  } else if (hasActiveFilters) {
    await performDiscover(1);
  } else {
    await loadBrowseRows();
  }
}

// Load Curated Browse Rows (Home View)
async function loadBrowseRows() {
  const requestId = ++state.catalogRequestId;
  showLoading();
  hideFilterBanner();
  elements.resultsGridSection.classList.add('hidden');
  elements.carouselsSection.classList.remove('hidden');

  try {
    const servicesParam = Array.from(state.selectedServices).join(',');
    const url = `/api/browse?country=${state.currentCountry}${servicesParam ? '&service=' + servicesParam : ''}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Network error');
    const data = await res.json();
    if (requestId !== state.catalogRequestId) return;
    renderCarousels(data.rows || []);
    hideLoading();
  } catch (err) {
    if (requestId !== state.catalogRequestId) return;
    console.error('Browse load error:', err);
    showError('Unable to connect to streaming catalog. Please verify your TMDB API Key.');
  }
}

// Discover / Filtered Catalog
async function performDiscover(page = 1) {
  const requestId = ++state.catalogRequestId;
  showLoading();
  updateFilterBanner();
  elements.carouselsSection.classList.add('hidden');
  elements.resultsGridSection.classList.remove('hidden');

  try {
    const servicesParam = Array.from(state.selectedServices).join(',');
    const params = new URLSearchParams({
      type: state.currentType,
      country: state.currentCountry,
      page
    });
    if (servicesParam) params.append('service', servicesParam);
    if (state.currentRating) params.append('rating', state.currentRating);
    if (state.currentGenre) params.append('genre', state.currentGenre);
    if (state.selectedCategories.size) params.append('categories', Array.from(state.selectedCategories).join(','));
    if (state.currentLanguage) params.append('language', state.currentLanguage);
    if (state.currentYear) params.append('year', state.currentYear);
    if (state.currentRuntime) params.append('runtime', state.currentRuntime);

    const res = await fetch(`/api/discover?${params.toString()}`);
    if (!res.ok) throw new Error('Discover error');
    const data = await res.json();
    if (requestId !== state.catalogRequestId) return;

    state.page = data.page;
    state.totalPages = data.totalPages;

    elements.gridTitle.textContent = 'Filtered Catalog';
    elements.gridCount.textContent = `${data.count} titles on page ${data.page}`;

    if (page === 1) {
      elements.resultsGrid.innerHTML = '';
    }

    if (page === 1 && (!data.results || data.results.length === 0)) {
      const selectedServices = Array.from(state.selectedServices)
        .map(id => state.services.find(service => service.id === id)?.name || id)
        .join(', ');
      elements.resultsGrid.innerHTML = `
        <div class="empty-watchlist-msg" style="grid-column: 1 / -1;">
          <i class="fa-solid fa-film"></i>
          <h3>No titles match these filters</h3>
          <p>${selectedServices ? `No movies or series from ${selectedServices} are listed in ${state.currentCountryName}. Try changing country or removing a service filter.` : 'Try relaxing the selected filters or changing country.'}</p>
        </div>
      `;
    } else {
      renderGridItems(data.results || []);
    }

    if (state.page < state.totalPages) {
      elements.paginationControls.classList.remove('hidden');
    } else {
      elements.paginationControls.classList.add('hidden');
    }

    hideLoading();
  } catch (err) {
    if (requestId !== state.catalogRequestId) return;
    console.error('Discover error:', err);
    showError('Failed to fetch filtered catalog.');
  }
}

// Search Titles
async function performSearch(page = 1) {
  if (!state.searchQuery.trim()) return refreshCatalog();

  const requestId = ++state.catalogRequestId;
  showLoading();
  updateFilterBanner();
  elements.carouselsSection.classList.add('hidden');
  elements.resultsGridSection.classList.remove('hidden');

  try {
    const params = new URLSearchParams({
      q: state.searchQuery.trim(),
      type: state.currentType,
      page
    });

    const res = await fetch(`/api/search?${params.toString()}`);
    if (!res.ok) throw new Error('Search error');
    const data = await res.json();
    if (requestId !== state.catalogRequestId) return;

    state.page = data.page;
    state.totalPages = data.totalPages;

    elements.gridTitle.textContent = `Search results for "${state.searchQuery}"`;
    elements.gridCount.textContent = `${data.count} titles found`;

    if (page === 1) {
      elements.resultsGrid.innerHTML = '';
    }

    if (!data.results || data.results.length === 0) {
      elements.resultsGrid.innerHTML = `
        <div class="empty-watchlist-msg" style="grid-column: 1 / -1;">
          <i class="fa-solid fa-magnifying-glass"></i>
          <h3>No titles found for "${state.searchQuery}"</h3>
          <p>Try searching for another movie, series, or director.</p>
        </div>
      `;
    } else {
      renderGridItems(data.results);
    }

    if (state.page < state.totalPages && data.results.length > 0) {
      elements.paginationControls.classList.remove('hidden');
    } else {
      elements.paginationControls.classList.add('hidden');
    }

    hideLoading();
  } catch (err) {
    if (requestId !== state.catalogRequestId) return;
    console.error('Search error:', err);
    showError('Search query failed.');
  }
}

// =========================================================
// Rendering Functions
// =========================================================

// Render Services Bar
const CATEGORY_FILTER_OPTIONS = [
  { id: 'trending', label: 'Trending' },
  { id: 'new-releases', label: 'New Releases' },
  { id: 'upcoming', label: 'Upcoming' },
  { id: 'highly-rated', label: 'Highly Rated' },
  { id: 'hidden-gems', label: 'Hidden Gems' },
  { id: 'free', label: 'Free to Watch' },
  { id: 'rent-buy', label: 'Rent / Buy' },
  { id: '4k', label: '4K', disabled: true },
  { id: 'hd', label: 'HD', disabled: true }
];

function renderCategoryFilters() {
  elements.categoryFilters.innerHTML = CATEGORY_FILTER_OPTIONS.map(option => `
    <button
      class="category-filter-chip ${state.selectedCategories.has(option.id) ? 'active' : ''} ${option.disabled ? 'unsupported' : ''}"
      type="button"
      data-category="${option.id}"
      aria-pressed="${state.selectedCategories.has(option.id)}"
      ${option.disabled ? 'disabled title="TMDB does not provide stream-resolution data for this title"' : ''}
    >${option.label}</button>
  `).join('');
}

function populateYearFilter() {
  const currentYear = new Date().getFullYear();
  elements.filterYear.innerHTML = '<option value="">Any</option>' + Array.from(
    { length: currentYear - 1979 },
    (_, index) => `<option value="${currentYear - index}">${currentYear - index}</option>`
  ).join('');
}

function renderServicesBar() {
  elements.servicesList.innerHTML = '';

  state.services.forEach(svc => {
    const btn = document.createElement('button');
    btn.className = `service-pill ${state.selectedServices.has(svc.id) ? 'active' : ''}`;
    btn.title = `Filter by ${svc.name}`;
    btn.dataset.id = svc.id;

    if (svc.logo) {
      const img = document.createElement('img');
      img.src = svc.logo;
      img.alt = svc.name;
      img.onerror = () => {
        img.remove();
        btn.innerHTML = `<span class="service-pill-text">${svc.name}</span>`;
      };
      btn.appendChild(img);
    } else {
      btn.innerHTML = `<span class="service-pill-text">${svc.name}</span>`;
    }

    btn.addEventListener('click', () => {
      if (state.selectedServices.has(svc.id)) {
        state.selectedServices.delete(svc.id);
        btn.classList.remove('active');
      } else {
        state.selectedServices.add(svc.id);
        btn.classList.add('active');
      }
      refreshCatalog();
    });

    elements.servicesList.appendChild(btn);
  });
}

// Render Carousels (Homepage)
function renderCarousels(rows) {
  elements.carouselsSection.innerHTML = '';

  if (rows.length === 0) {
    elements.carouselsSection.innerHTML = `
      <div class="empty-watchlist-msg">
        <i class="fa-solid fa-film"></i>
        <h3>No titles found in this catalog</h3>
        <p>Try switching streaming services or changing country.</p>
      </div>
    `;
    return;
  }

  rows.forEach(row => {
    if (!row.items || row.items.length === 0) return;

    const rowEl = document.createElement('div');
    rowEl.className = 'carousel-row';
    rowEl.id = `row-${row.id}`;

    // Header
    const headerEl = document.createElement('div');
    headerEl.className = 'carousel-header';
    headerEl.innerHTML = `
      <div class="carousel-title-group">
        <h2 class="carousel-title">${row.title}</h2>
        ${row.subtitle ? `<span class="carousel-subtitle">${row.subtitle}</span>` : ''}
      </div>
      <div class="carousel-controls">
        <button class="carousel-btn btn-prev" aria-label="Scroll left"><i class="fa-solid fa-chevron-left"></i></button>
        <button class="carousel-btn btn-next" aria-label="Scroll right"><i class="fa-solid fa-chevron-right"></i></button>
      </div>
    `;

    // Track Wrapper
    const trackWrapper = document.createElement('div');
    trackWrapper.className = 'carousel-track-wrapper';

    const track = document.createElement('div');
    track.className = 'carousel-track';

    row.items.forEach(item => {
      const card = createCardElement(item);
      track.appendChild(card);
    });

    trackWrapper.appendChild(track);
    rowEl.appendChild(headerEl);
    rowEl.appendChild(trackWrapper);
    elements.carouselsSection.appendChild(rowEl);

    // Carousel buttons scroll logic
    const prevBtn = headerEl.querySelector('.btn-prev');
    const nextBtn = headerEl.querySelector('.btn-next');

    prevBtn.addEventListener('click', () => {
      track.scrollBy({ left: -600, behavior: 'smooth' });
    });
    nextBtn.addEventListener('click', () => {
      track.scrollBy({ left: 600, behavior: 'smooth' });
    });
  });
}

// Render Grid Items (Search / Filter View)
function renderGridItems(items) {
  items.forEach(item => {
    const card = createCardElement(item);
    elements.resultsGrid.appendChild(card);
  });
}

// Create Card Element
function createCardElement(item) {
  const card = document.createElement('div');
  card.className = 'show-card';
  card.dataset.id = item.id;
  card.dataset.type = item.showType;

  const inWatchlist = isItemInWatchlist(item.id, item.showType);
  const imageSrc = item.backdropUrl || item.posterUrl || 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&auto=format&fit=crop&q=60';

  card.innerHTML = `
    <div class="card-media">
      <img src="${imageSrc}" alt="${item.title}" loading="lazy" decoding="async">
      ${item.isRecentlyAdded ? '<span class="badge-recent">Recently Added</span>' : ''}
      <div class="card-quick-actions">
        <button class="btn-card-action btn-watchlist-card ${inWatchlist ? 'in-watchlist' : ''}" title="${inWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist'}">
          <i class="fa-solid ${inWatchlist ? 'fa-check' : 'fa-bookmark'}"></i>
        </button>
      </div>
    </div>
    <div class="card-details">
      <div class="card-meta-row">
        <div class="card-rating">
          <i class="fa-solid fa-star rating-star"></i>
          <span>${item.rating ? item.rating : 'N/A'}</span>
        </div>
        ${item.releaseYear ? `<span class="card-year">${item.releaseYear}</span>` : ''}
        <span class="card-type-tag">${item.showType === 'tv' ? 'SERIES' : 'MOVIE'}</span>
      </div>
      <div class="card-title" title="${item.title}">${item.title}</div>
    </div>
  `;

  // Quick Watchlist Toggle
  const wlBtn = card.querySelector('.btn-watchlist-card');
  wlBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleWatchlist(item);
    const active = isItemInWatchlist(item.id, item.showType);
    wlBtn.classList.toggle('in-watchlist', active);
    wlBtn.innerHTML = `<i class="fa-solid ${active ? 'fa-check' : 'fa-bookmark'}"></i>`;
  });

  // Open Details Modal on Click
  card.addEventListener('click', () => {
    openDetailsModal(item.showType, item.id);
  });

  return card;
}

// Render Country Picker Grid
function renderCountryPickerGrid(filter = '') {
  elements.countriesGrid.innerHTML = '';
  const filtered = state.countries.filter(c => 
    c.name.toLowerCase().includes(filter.toLowerCase()) || 
    c.code.toLowerCase().includes(filter.toLowerCase())
  );

  filtered.forEach(country => {
    const btn = document.createElement('button');
    btn.className = `country-btn ${state.currentCountry === country.code ? 'active' : ''}`;
    btn.innerHTML = `
      <span class="flag">${country.flag}</span>
      <span>${country.name} (${country.code})</span>
    `;

    btn.addEventListener('click', () => {
      state.currentCountry = country.code;
      state.currentCountryFlag = country.flag;
      state.currentCountryName = country.name;
      elements.currentFlag.textContent = country.flag;
      elements.currentCountryCode.textContent = country.code;
      localStorage.setItem('motn_country', country.code);
      closeModal(elements.countryModal);
      showToast(`Switched region to ${country.name}`);
      refreshCatalog();
    });

    elements.countriesGrid.appendChild(btn);
  });
}

// =========================================================
// Details Modal Logic
// =========================================================
async function openDetailsModal(type, id) {
  elements.detailsContent.innerHTML = `
    <div class="loading-container">
      <div class="spinner"></div>
      <p>Loading show details and streaming availability...</p>
    </div>
  `;
  openModal(elements.detailsModal);

  try {
    const res = await fetch(`/api/details/${type}/${id}?country=${state.currentCountry}`);
    if (!res.ok) throw new Error('Details not found');
    const data = await res.json();
    recordRecentActivity(data);
    renderDetailsContent(data);
  } catch (err) {
    console.error('Failed to load details:', err);
    elements.detailsContent.innerHTML = `
      <div class="error-container">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <h3>Failed to load show details</h3>
        <p>Please check your connection and try again.</p>
      </div>
    `;
  }
}

function getProviderDirectLink(providerName, title) {
  const normalized = (providerName || '').toLowerCase();
  const encodedTitle = encodeURIComponent(title || '');

  const providerMap = {
    netflix: `https://www.netflix.com/search?q=${encodedTitle}`,
    'prime video': `https://www.primevideo.com/search?phrase=${encodedTitle}`,
    'disney+': `https://www.disneyplus.com/search?q=${encodedTitle}`,
    'apple tv': `https://tv.apple.com/search?term=${encodedTitle}`,
    'apple tv+': `https://tv.apple.com/search?term=${encodedTitle}`,
    'hbo max': `https://play.max.com/search?q=${encodedTitle}`,
    'paramount+': `https://www.paramountplus.com/search/?q=${encodedTitle}`,
    hulu: `https://www.hulu.com/search?q=${encodedTitle}`,
    peacock: `https://www.peacocktv.com/search?q=${encodedTitle}`,
    'bbc iplayer': `https://www.bbc.co.uk/iplayer/search?q=${encodedTitle}`,
    itvx: `https://www.itv.com/search?q=${encodedTitle}`,
    'channel 4': `https://www.channel4.com/anysearch?searchterm=${encodedTitle}`,
    all4: `https://www.channel4.com/anysearch?searchterm=${encodedTitle}`,
    mubi: `https://mubi.com/search?q=${encodedTitle}`,
    'discovery+': `https://www.discoveryplus.com/search?q=${encodedTitle}`,
    'curiosity stream': `https://curiositystream.com/search?q=${encodedTitle}`,
    'pluto tv': `https://pluto.tv/search?q=${encodedTitle}`,
    zee5: `https://www.zee5.com/search?query=${encodedTitle}`
  };

  const match = Object.entries(providerMap).find(([key]) => normalized.includes(key));
  if (match) return match[1];

  if (providerName) {
    return `https://www.google.com/search?q=${encodeURIComponent(`${title || providerName} ${providerName}`)}`;
  }

  return 'https://www.google.com';
}

function preloadDetailsBackdrop(url) {
  if (!url || state.backdropPreloadCache.has(url)) return;
  const image = new Image();
  image.decoding = 'async';
  image.fetchPriority = 'high';
  image.src = url;
  state.backdropPreloadCache.set(url, image);
  if (state.backdropPreloadCache.size > 8) {
    state.backdropPreloadCache.delete(state.backdropPreloadCache.keys().next().value);
  }
}

function renderDetailsContent(data) {
  state.currentDetailItem = data;
  const inWatchlist = isItemInWatchlist(data.id, data.showType);
  const personalRating = state.userRatings.find(item => getPersonalKey(item) === getPersonalKey(data))?.userRating || '';
  const heroImage = data.backdropUrl || '';
  const countryObj = state.countries.find(c => c.code === state.currentCountry) || { name: state.currentCountry, flag: '' };

  const streamOpts = data.streamingOptions || {};
  const streamProviders = streamOpts.stream || [];
  const rentProviders = streamOpts.rent || [];
  const buyProviders = streamOpts.buy || [];

  const hasAnyProviders = streamProviders.length > 0 || rentProviders.length > 0 || buyProviders.length > 0;

  let streamHtml = '';
  if (streamProviders.length > 0) {
    streamHtml += `
      <div class="provider-subgroup">
        <div class="provider-subgroup-title"><i class="fa-solid fa-play-circle"></i> Stream (Subscription)</div>
        <div class="provider-logos-row">
          ${streamProviders.map(p => `
            <a href="${getProviderDirectLink(p.name, data.title)}" target="_blank" rel="noopener" class="provider-chip" title="Watch on ${p.name}">
              <img src="${p.logo}" alt="${p.name}">
              <span>${p.name}</span>
            </a>
          `).join('')}
        </div>
      </div>
    `;
  }

  if (rentProviders.length > 0) {
    streamHtml += `
      <div class="provider-subgroup">
        <div class="provider-subgroup-title"><i class="fa-solid fa-ticket"></i> Rent</div>
        <div class="provider-logos-row">
          ${rentProviders.map(p => `
            <a href="${getProviderDirectLink(p.name, data.title)}" target="_blank" rel="noopener" class="provider-chip" title="Rent on ${p.name}">
              <img src="${p.logo}" alt="${p.name}">
              <span>${p.name}</span>
            </a>
          `).join('')}
        </div>
      </div>
    `;
  }

  if (buyProviders.length > 0) {
    streamHtml += `
      <div class="provider-subgroup">
        <div class="provider-subgroup-title"><i class="fa-solid fa-cart-shopping"></i> Buy</div>
        <div class="provider-logos-row">
          ${buyProviders.map(p => `
            <a href="${getProviderDirectLink(p.name, data.title)}" target="_blank" rel="noopener" class="provider-chip" title="Buy on ${p.name}">
              <img src="${p.logo}" alt="${p.name}">
              <span>${p.name}</span>
            </a>
          `).join('')}
        </div>
      </div>
    `;
  }

  if (!hasAnyProviders) {
    streamHtml = `
      <div class="no-providers-msg">
        <p>No streaming subscription or digital store currently lists this title in <strong>${countryObj.name}</strong>.</p>
        ${streamOpts.allCountriesAvailable?.length > 0 ? `
          <p style="margin-top: 0.4rem; font-size: 0.82rem; color: var(--text-subtle);">
            Available in other countries: ${streamOpts.allCountriesAvailable.slice(0, 10).join(', ')}
          </p>
        ` : ''}
      </div>
    `;
  }

  elements.detailsContent.innerHTML = `
    <!-- Hero Banner -->
    <div class="details-hero${heroImage ? '' : ' no-backdrop'}">
      <div class="details-hero-content">
        <h1 class="details-title">${data.title}</h1>
        ${data.tagline ? `<p class="details-tagline">"${data.tagline}"</p>` : ''}
        
        <div class="details-badges-row">
          <div class="badge-rating-pill">
            <i class="fa-solid fa-star"></i>
            <span>${data.rating || 'N/A'} / 10</span>
          </div>
          <span class="details-rating-source">TMDB community rating · ${(Number(data.voteCount) || 0).toLocaleString()} ratings</span>
          ${data.releaseYear ? `<span class="badge-info-pill">${data.releaseYear}</span>` : ''}
          ${data.runtime ? `<span class="badge-info-pill">${Math.floor(data.runtime / 60)}h ${data.runtime % 60}m</span>` : ''}
          ${data.seasonsCount ? `<span class="badge-info-pill">${data.seasonsCount} Season${data.seasonsCount > 1 ? 's' : ''}</span>` : ''}
          <span class="badge-info-pill" style="text-transform: uppercase;">${data.showType}</span>
          ${(data.genres || []).map(g => `<span class="badge-info-pill">${g.name}</span>`).join('')}
        </div>

        <div class="details-action-buttons">
          ${data.trailer ? `
            <button class="btn-play-trailer" id="modalTrailerBtn">
              <i class="fa-solid fa-play"></i> Watch Trailer
            </button>
          ` : ''}
          <button class="btn-watchlist-toggle ${inWatchlist ? 'active' : ''}" id="modalWatchlistBtn">
            <i class="fa-solid ${inWatchlist ? 'fa-check' : 'fa-bookmark'}"></i>
            <span>${inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}</span>
          </button>
          <button class="btn-watchlist-toggle ${isItemMarkedWatched(data) ? 'active' : ''}" id="modalMarkWatchedBtn" type="button"><i class="fa-solid ${isItemMarkedWatched(data) ? 'fa-check' : 'fa-eye'}"></i> ${isItemMarkedWatched(data) ? 'Watched' : 'Mark Watched'}</button>
          <label class="modal-user-rating">My Rating<select id="modalUserRating" aria-label="My rating"><option value="">Rate</option>${Array.from({ length: 10 }, (_, index) => index + 1).map(value => `<option value="${value}" ${Number(personalRating) === value ? 'selected' : ''}>${value}/10</option>`).join('')}</select></label>
          <button class="btn-watchlist-toggle" id="modalWatchLinkBtn" type="button"><i class="fa-solid fa-link"></i> Watch With Me</button>
        </div>
      </div>
    </div>

    <!-- Details Body -->
    <div class="details-body">
      <div class="details-intro-layout">
        <div class="details-poster-frame">${data.posterUrl ? `<img class="details-poster" src="${data.posterUrl}" alt="${data.title} poster" loading="lazy" decoding="async">` : '<div class="details-poster-fallback"><i class="fa-solid fa-film"></i><span>Poster unavailable</span></div>'}</div>
        <div class="details-intro-copy">
          <div class="details-section">
            <h4><i class="fa-solid fa-align-left"></i> Storyline</h4>
            <p class="details-overview">${data.overview || 'No synopsis available.'}</p>
          </div>
          <div class="details-section">
            <h4><i class="fa-solid fa-tv"></i> Where to Watch in ${countryObj.name} ${countryObj.flag}</h4>
            <div class="streaming-providers-group">${streamHtml}</div>
          </div>
        </div>
      </div>

      ${data.collection?.id ? `<div class="details-section">
        <h4><i class="fa-solid fa-film"></i> Watch Order: ${escapeHtml(data.collection.name)}</h4>
        <button class="dashboard-text-button" id="loadWatchOrderBtn" type="button" data-collection-id="${data.collection.id}">Show Watch Order</button>
        <div id="watchOrderContent"></div>
      </div>` : ''}

      <!-- Cast -->
      ${data.cast && data.cast.length > 0 ? `
        <div class="details-section">
          <h4><i class="fa-solid fa-users"></i> Top Cast</h4>
          <div class="cast-list">
            ${data.cast.map(c => `
              <button class="cast-card" type="button" data-actor-id="${c.id}" aria-label="View ${c.name} actor profile">
                ${c.profilePath ? `<img class="cast-avatar" src="${c.profilePath}" alt="${c.name}" loading="lazy" decoding="async">` : '<span class="cast-avatar cast-avatar-fallback"><i class="fa-solid fa-user"></i></span>'}
                <div class="cast-name" title="${c.name}">${c.name}</div>
                <div class="cast-character" title="${c.character}">${c.character}</div>
              </button>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Recommendations -->
      ${data.recommendations && data.recommendations.length > 0 ? `
        <div class="details-section">
          <h4><i class="fa-solid fa-thumbs-up"></i> You Might Also Like</h4>
          <div class="carousel-track" style="padding-top: 0.5rem;">
            ${data.recommendations.map(r => `
              <div class="show-card" style="flex: 0 0 200px;" onclick="window.loadRecommendation('${r.showType}', ${r.id})">
                <div class="card-media">
                  <img src="${r.backdropUrl || r.posterUrl}" alt="${r.title}" loading="lazy" decoding="async">
                </div>
                <div class="card-details">
                  <div class="card-title">${r.title}</div>
                  <div class="card-year">${r.releaseYear || ''}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <section class="details-section reviews-ratings-section" aria-labelledby="movieReviewsHeading">
        <div class="reviews-section-heading">
          <h4 id="movieReviewsHeading"><i class="fa-solid fa-star-half-stroke"></i> Reviews &amp; Ratings</h4>
          <span class="review-source-label">External reviews: TMDB</span>
        </div>
        <div class="movie-rating-summary">
          <div class="movie-rating-summary-score"><strong>${data.rating || 'N/A'}</strong><span> / 10 from TMDB<br>${(Number(data.voteCount) || 0).toLocaleString()} ratings</span></div>
          <div id="movieRatingDistribution" class="movie-rating-distribution"><p class="dashboard-empty-inline">Loading available review ratings...</p></div>
        </div>
        <div id="myMovieReviewEditor" class="my-movie-review-editor"></div>
        <div class="reviews-list-heading">
          <h5>TMDB Reviews <span id="externalReviewCount">Loading…</span></h5>
          <label>Sort
            <select id="movieReviewSort">
              <option value="newest">Newest</option>
              <option value="highest">Highest rating</option>
              <option value="lowest">Lowest rating</option>
              <option value="helpful" disabled>Most helpful (not provided by TMDB)</option>
            </select>
          </label>
        </div>
        <p class="review-source-note">TMDB does not provide helpful-vote counts. User reviews you submit are private to this browser and are not included in TMDB ratings.</p>
        <div id="externalReviewList" class="external-review-list"><p class="dashboard-empty-inline">Loading TMDB reviews…</p></div>
      </section>

    </div>
  `;

  const detailsHero = elements.detailsContent.querySelector('.details-hero');
  if (detailsHero && heroImage) {
    preloadDetailsBackdrop(heroImage);
    detailsHero.style.setProperty('--details-backdrop', `url("${heroImage}")`);
  }

  // Attach Trailer Click
  const trailerBtn = document.getElementById('modalTrailerBtn');
  if (trailerBtn && data.trailer) {
    trailerBtn.addEventListener('click', () => {
      openVideoModal(data.trailer.embedUrl);
    });
  }

  // Attach Watchlist Button
  const wlBtn = document.getElementById('modalWatchlistBtn');
  if (wlBtn) {
    wlBtn.addEventListener('click', () => {
      toggleWatchlist(data);
      const active = isItemInWatchlist(data.id, data.showType);
      wlBtn.classList.toggle('active', active);
      wlBtn.innerHTML = `
        <i class="fa-solid ${active ? 'fa-check' : 'fa-bookmark'}"></i>
        <span>${active ? 'In Watchlist' : 'Add to Watchlist'}</span>
      `;
    });
  }

  document.getElementById('modalMarkWatchedBtn')?.addEventListener('click', () => {
    if (!isItemMarkedWatched(data)) markItemWatched(data);
  });
  document.getElementById('modalUserRating')?.addEventListener('change', event => savePersonalRating(data, event.target.value));
  document.getElementById('modalWatchLinkBtn')?.addEventListener('click', () => copyWatchWithMeLink(data));
  document.getElementById('loadWatchOrderBtn')?.addEventListener('click', event => loadCollectionWatchOrder(event.currentTarget.dataset.collectionId));
  document.getElementById('movieReviewSort')?.addEventListener('change', event => {
    state.movieReviewSort = event.target.value;
    const cachedReviews = state.movieReviewsCache.get(`${data.showType}:${data.id}`);
    if (cachedReviews) renderExternalReviews(cachedReviews, state.movieReviewSort);
  });
  renderMyMovieReviewEditor(data);
  loadMovieReviews(data.showType, data.id);
}

function getReviewOwnerKey() {
  return state.user?.email || state.user?.name || '';
}

function getMyMovieReview(item) {
  const ownerKey = getReviewOwnerKey();
  if (!ownerKey) return null;
  return state.localMovieReviews.find(review =>
    review.showType === item.showType && review.movieId === item.id && review.ownerKey === ownerKey
  ) || null;
}

function renderMyMovieReviewEditor(item) {
  const mount = document.getElementById('myMovieReviewEditor');
  if (!mount) return;
  const ownReview = getMyMovieReview(item);
  if (!state.user) {
    mount.innerHTML = `
      <div class="my-review-heading"><h5>Your private review</h5><span>Saved only in this browser</span></div>
      <p class="review-source-note">Sign in with this browser profile to add a private rating and review. This local session is not a shared account.</p>
      <button class="dashboard-text-button" id="reviewSignInBtn" type="button">Sign In</button>
    `;
    document.getElementById('reviewSignInBtn')?.addEventListener('click', () => elements.logInBtn.click());
    return;
  }

  mount.innerHTML = `
    <div class="my-review-heading"><h5>Your private review</h5><span>${ownReview ? `Updated ${new Date(ownReview.updatedAt).toLocaleDateString()}` : 'Not shared with other users'}</span></div>
    <form id="localMovieReviewForm" class="local-movie-review-form" novalidate>
      <label for="localMovieReviewRating">Your rating <span>1–10</span></label>
      <select id="localMovieReviewRating" required aria-required="true"><option value="">Select rating</option>${Array.from({ length: 10 }, (_, index) => index + 1).map(value => `<option value="${value}" ${ownReview?.rating === value ? 'selected' : ''}>${value}/10</option>`).join('')}</select>
      <label for="localMovieReviewText">Your review</label>
      <textarea id="localMovieReviewText" rows="4" maxlength="2000" required aria-required="true" placeholder="Write a review (up to 2,000 characters)">${ownReview ? escapeHtml(ownReview.text) : ''}</textarea>
      <div class="local-review-form-footer"><span id="localMovieReviewError" role="alert"></span><div><button class="btn-primary" type="submit">${ownReview ? 'Update Review' : 'Save Review'}</button>${ownReview ? '<button class="dashboard-text-button" id="deleteLocalReviewBtn" type="button">Delete</button>' : ''}</div></div>
    </form>
  `;
  document.getElementById('localMovieReviewForm')?.addEventListener('submit', event => {
    event.preventDefault();
    const ratingValue = Number(document.getElementById('localMovieReviewRating').value);
    const text = document.getElementById('localMovieReviewText').value.trim();
    const error = document.getElementById('localMovieReviewError');
    if (!Number.isInteger(ratingValue) || ratingValue < 1 || ratingValue > 10) {
      error.textContent = 'Choose a rating from 1 to 10.';
      return;
    }
    if (!text) {
      error.textContent = 'Write a review before saving.';
      return;
    }
    if (text.length > 2000) {
      error.textContent = 'Reviews must be 2,000 characters or fewer.';
      return;
    }
    const now = new Date().toISOString();
    const review = {
      movieId: item.id,
      showType: item.showType,
      ownerKey: getReviewOwnerKey(),
      author: state.user.name || 'You',
      rating: ratingValue,
      text,
      createdAt: ownReview?.createdAt || now,
      updatedAt: now
    };
    state.localMovieReviews = state.localMovieReviews.filter(saved =>
      saved.showType !== item.showType || saved.movieId !== item.id || saved.ownerKey !== review.ownerKey
    );
    state.localMovieReviews.unshift(review);
    localStorage.setItem('motn_movie_reviews', JSON.stringify(state.localMovieReviews));
    renderMyMovieReviewEditor(item);
    showToast(ownReview ? 'Your review was updated on this device.' : 'Your private review was saved on this device.');
  });
  document.getElementById('deleteLocalReviewBtn')?.addEventListener('click', () => {
    state.localMovieReviews = state.localMovieReviews.filter(saved =>
      saved.showType !== item.showType || saved.movieId !== item.id || saved.ownerKey !== getReviewOwnerKey()
    );
    localStorage.setItem('motn_movie_reviews', JSON.stringify(state.localMovieReviews));
    renderMyMovieReviewEditor(item);
    showToast('Your private review was deleted.');
  });
}

async function loadMovieReviews(type, id) {
  const key = `${type}:${id}`;
  const cachedReviews = state.movieReviewsCache.get(key);
  if (cachedReviews) {
    renderExternalReviews(cachedReviews, state.movieReviewSort);
    return;
  }
  try {
    const response = await fetch(`/api/reviews/${type}/${id}`);
    if (!response.ok) throw new Error('TMDB reviews unavailable');
    const data = await response.json();
    state.movieReviewsCache.set(key, data);
    renderExternalReviews(data, state.movieReviewSort);
  } catch (error) {
    console.error('Failed to load TMDB reviews:', error);
    const list = document.getElementById('externalReviewList');
    const count = document.getElementById('externalReviewCount');
    const distribution = document.getElementById('movieRatingDistribution');
    if (count) count.textContent = 'Unavailable';
    if (list) list.innerHTML = '<p class="dashboard-empty-inline">TMDB reviews are temporarily unavailable.</p>';
    if (distribution) distribution.innerHTML = '<p class="dashboard-empty-inline">No review-rating sample is available.</p>';
  }
}

function renderExternalReviews(data, sort = 'newest') {
  const list = document.getElementById('externalReviewList');
  const count = document.getElementById('externalReviewCount');
  const distribution = document.getElementById('movieRatingDistribution');
  if (!list || !count || !distribution) return;
  count.textContent = `${Number(data.totalResults || 0).toLocaleString()} total`;
  const reviews = [...(data.results || [])];
  if (sort === 'highest') reviews.sort((a, b) => (b.rating ?? -1) - (a.rating ?? -1));
  else if (sort === 'lowest') reviews.sort((a, b) => (a.rating ?? 11) - (b.rating ?? 11));
  else reviews.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

  const ratedReviews = (data.results || []).filter(review => Number.isFinite(review.rating) && review.rating >= 1 && review.rating <= 10);
  const distributionCounts = Array.from({ length: 10 }, () => 0);
  ratedReviews.forEach(review => distributionCounts[Math.max(0, Math.min(9, Math.round(review.rating) - 1))] += 1);
  const maxCount = Math.max(1, ...distributionCounts);
  distribution.innerHTML = ratedReviews.length ? `
    <p class="rating-distribution-caption">Distribution among ${ratedReviews.length} rated reviews on this TMDB page</p>
    ${distributionCounts.map((amount, index) => {
      const score = 10 - index;
      return `<div class="rating-distribution-row" aria-label="${score} out of 10: ${amount} reviews"><span>${score} ★</span><i><b style="width:${amount / maxCount * 100}%"></b></i><small>${amount}</small></div>`;
    }).join('')}
  ` : '<p class="dashboard-empty-inline">TMDB does not provide rating breakdown data for this review sample.</p>';

  list.innerHTML = reviews.length ? reviews.map(review => `
    <article class="external-review-item">
      <div class="external-review-meta"><strong>${escapeHtml(review.author || 'TMDB member')}</strong><span>${review.rating ? `${escapeHtml(review.rating)}/10` : 'No rating'}</span><time>${review.createdAt ? new Date(review.createdAt).toLocaleDateString() : 'Date unavailable'}</time></div>
      <p>${escapeHtml((review.content || '').slice(0, 1800))}${review.content?.length > 1800 ? '…' : ''}</p>
      ${review.url ? `<a href="${escapeHtml(review.url)}" target="_blank" rel="noopener noreferrer">View source on TMDB</a>` : ''}
    </article>
  `).join('') : '<p class="dashboard-empty-inline">No external reviews are listed on TMDB for this title yet.</p>';
}

async function copyWatchWithMeLink(item) {
  const shareUrl = new URL(window.location.href);
  shareUrl.hash = '';
  shareUrl.search = '';
  shareUrl.searchParams.set('watch', `${item.showType}/${item.id}`);
  shareUrl.searchParams.set('country', state.currentCountry);
  try {
    await navigator.clipboard.writeText(shareUrl.toString());
    showToast('Watch link copied. It contains no personal account information.');
  } catch (error) {
    const input = document.createElement('textarea');
    input.value = shareUrl.toString();
    input.setAttribute('readonly', '');
    input.style.position = 'fixed';
    input.style.opacity = '0';
    document.body.appendChild(input);
    input.select();
    const copied = document.execCommand('copy');
    input.remove();
    showToast(copied ? 'Watch link copied.' : 'Unable to copy the watch link in this browser.');
  }
}

async function loadCollectionWatchOrder(collectionId) {
  const content = document.getElementById('watchOrderContent');
  if (!content) return;
  content.innerHTML = '<p class="dashboard-empty-inline">Loading collection titles...</p>';
  try {
    let collection = state.collectionCache.get(collectionId);
    if (!collection) {
      const response = await fetch(`/api/collections/${collectionId}`);
      if (!response.ok) throw new Error('Collection unavailable');
      collection = await response.json();
      state.collectionCache.set(collectionId, collection);
    }
    renderCollectionOrder(collection, 'release');
  } catch (error) {
    console.error('Watch order failed:', error);
    content.innerHTML = '<p class="dashboard-empty-inline">TMDB does not have watch-order data for this collection.</p>';
  }
}

function renderCollectionOrder(collection, mode) {
  const content = document.getElementById('watchOrderContent');
  if (!content) return;
  const films = [...(collection.parts || [])].sort((a, b) => {
    const dateA = a.releaseDate ? new Date(a.releaseDate).getTime() : Number.MAX_SAFE_INTEGER;
    const dateB = b.releaseDate ? new Date(b.releaseDate).getTime() : Number.MAX_SAFE_INTEGER;
    return dateA - dateB || a.title.localeCompare(b.title);
  });
  content.innerHTML = `
    <div class="watch-order-tabs"><button type="button" data-order-mode="release" class="${mode === 'release' ? 'active' : ''}">Release Order</button><button type="button" data-order-mode="chronological" class="${mode === 'chronological' ? 'active' : ''}">Chronological Order</button></div>
    ${mode === 'chronological'
      ? '<p class="dashboard-empty-inline">An in-universe chronological order is not provided by TMDB. Release dates are available, but are not treated as story chronology.</p>'
      : films.length ? `<ol class="watch-order-list">${films.map(film => `<li><button type="button" data-watch-order-movie="${film.id}">${escapeHtml(film.title)}</button>${film.releaseYear ? `<span>${film.releaseYear}</span>` : ''}</li>`).join('')}</ol>` : '<p class="dashboard-empty-inline">No collection titles are listed.</p>'}
  `;
  content.querySelectorAll('[data-order-mode]').forEach(button => {
    button.addEventListener('click', () => renderCollectionOrder(collection, button.dataset.orderMode));
  });
  content.querySelectorAll('[data-watch-order-movie]').forEach(button => {
    button.addEventListener('click', () => openDetailsModal('movie', button.dataset.watchOrderMovie));
  });
}

// Window helper for recommendations
window.loadRecommendation = function(type, id) {
  openDetailsModal(type, id);
};

// =========================================================
// Watchlist Management
// =========================================================
function isItemInWatchlist(id, showType = 'movie') {
  return state.watchlist.some(w => w.id === id && (w.showType || 'movie') === showType);
}

function toggleWatchlist(item) {
  const index = state.watchlist.findIndex(w => w.id === item.id && (w.showType || 'movie') === (item.showType || 'movie'));
  if (index >= 0) {
    state.watchlist.splice(index, 1);
    showToast(`Removed "${item.title}" from watchlist`);
  } else {
    state.watchlist.unshift({
      id: item.id,
      title: item.title,
      showType: item.showType,
      releaseYear: item.releaseYear,
      rating: item.rating,
      backdropUrl: item.backdropUrl,
      posterUrl: item.posterUrl,
      addedAt: new Date().toISOString(),
      category: item.category || 'To Watch',
      genres: item.genres || [],
      providerNames: getItemProviderNames(item)
    });
    showToast(`Added "${item.title}" to watchlist`);
  }
  localStorage.setItem('motn_watchlist', JSON.stringify(state.watchlist));
  state.dashboardRecommendationsCache.clear();
  updateWatchlistBadge();
  renderWatchlistDrawer();
  if (!elements.dashboardPage.classList.contains('hidden')) renderPersonalDashboard();
}

function updateWatchlistBadge() {
  elements.watchlistCount.textContent = state.watchlist.length;
}

function renderWatchlistDrawer() {
  elements.watchlistItemsContainer.innerHTML = '';

  if (state.watchlist.length === 0) {
    elements.watchlistItemsContainer.innerHTML = `
      <div class="empty-watchlist-msg">
        <i class="fa-solid fa-bookmark"></i>
        <h3>Your watchlist is empty</h3>
        <p>Save movies and shows you want to watch later by clicking the bookmark icon.</p>
      </div>
    `;
    return;
  }

  state.watchlist.forEach(item => {
    const card = document.createElement('div');
    card.className = 'watchlist-item-card';
    const thumb = item.backdropUrl || item.posterUrl || '';

    card.innerHTML = `
      <img class="watchlist-item-thumb" src="${thumb}" alt="${item.title}">
      <div class="watchlist-item-info">
        <div class="watchlist-item-title">${item.title}</div>
        <div class="watchlist-item-meta">
          <span>★ ${item.rating || 'N/A'}</span>
          <span>•</span>
          <span>${item.releaseYear || ''}</span>
          <span>•</span>
          <span style="text-transform: uppercase;">${item.showType}</span>
        </div>
      </div>
      <button class="btn-remove-watchlist" title="Remove"><i class="fa-solid fa-trash-can"></i></button>
    `;

    card.addEventListener('click', () => {
      closeModal(elements.watchlistDrawer);
      openDetailsModal(item.showType, item.id);
    });

    const removeBtn = card.querySelector('.btn-remove-watchlist');
    removeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleWatchlist(item);
    });

    elements.watchlistItemsContainer.appendChild(card);
  });
}

// =========================================================
// UI States & Banners
// =========================================================
function showLoading() {
  elements.loadingIndicator.classList.remove('hidden');
  elements.errorMessage.classList.add('hidden');
}

function hideLoading() {
  elements.loadingIndicator.classList.add('hidden');
}

function showError(msg) {
  hideLoading();
  elements.errorMessage.classList.remove('hidden');
  elements.errorDescription.textContent = msg;
}

function updateFilterBanner() {
  const parts = [];
  if (state.searchQuery) parts.push(`Query: "${state.searchQuery}"`);
  if (state.currentType !== 'all') parts.push(`Type: ${state.currentType === 'movie' ? 'Movies' : 'Series'}`);
  if (state.currentGenre) parts.push(`Genre: ${elements.selectedGenreText.textContent}`);
  if (state.currentRating) parts.push(`Rating: ${elements.selectedRatingText.textContent}`);
  if (state.selectedServices.size > 0) parts.push(`Services: ${Array.from(state.selectedServices).join(', ').toUpperCase()}`);
  if (state.selectedCategories.size > 0) {
    parts.push(Array.from(state.selectedCategories).map(id => CATEGORY_FILTER_OPTIONS.find(option => option.id === id)?.label || id).join(', '));
  }
  if (state.currentLanguage) parts.push(`Language: ${elements.filterLanguage.selectedOptions[0].textContent}`);
  if (state.currentYear) parts.push(`Year: ${state.currentYear}`);
  if (state.currentRuntime) parts.push(`Runtime: up to ${state.currentRuntime} min`);

  if (parts.length > 0) {
    elements.filterBannerText.textContent = `Active Filters: ${parts.join(' | ')}`;
    elements.filterBanner.classList.remove('hidden');
  } else {
    hideFilterBanner();
  }
}

function hideFilterBanner() {
  elements.filterBanner.classList.add('hidden');
}

function resetAllFilters() {
  state.searchQuery = '';
  elements.searchInput.value = '';
  elements.clearSearchBtn.classList.add('hidden');

  state.currentType = 'all';
  elements.selectedTypeText.textContent = 'Movies & Series';
  document.querySelectorAll('#dropdownType .dropdown-item').forEach(el => {
    el.classList.toggle('active', el.dataset.value === 'all');
  });

  state.currentRating = '';
  elements.selectedRatingText.textContent = 'Rating: All';
  document.querySelectorAll('#dropdownRating .dropdown-item').forEach(el => {
    el.classList.toggle('active', el.dataset.value === '');
  });

  state.currentGenre = '';
  elements.selectedGenreText.textContent = 'Genres: All';
  document.querySelectorAll('#dropdownGenre .dropdown-item').forEach(el => {
    el.classList.toggle('active', el.dataset.value === '');
  });

  state.selectedServices.clear();
  document.querySelectorAll('.service-pill').forEach(el => el.classList.remove('active'));

  state.selectedCategories.clear();
  state.currentLanguage = '';
  state.currentYear = '';
  state.currentRuntime = '';
  elements.filterLanguage.value = '';
  elements.filterYear.value = '';
  elements.filterRuntime.value = '';
  renderCategoryFilters();

  hideFilterBanner();
  refreshCatalog();
}

// Toast Notifications
function showToast(message) {
  elements.toastMsg.textContent = message;
  elements.toast.classList.remove('hidden');
  setTimeout(() => {
    elements.toast.classList.add('hidden');
  }, 3000);
}

// Modal Helpers
function openModal(el) {
  el.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal(el) {
  el.classList.add('hidden');
  document.body.style.overflow = '';
}

function openVideoModal(embedUrl) {
  elements.videoContainer.innerHTML = `<iframe src="${embedUrl}?autoplay=1" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
  openModal(elements.videoModal);
}

// User Session
function checkUserSession() {
  if (state.user) {
    elements.signUpBtn.classList.add('hidden');
    elements.logInBtn.classList.add('hidden');
    elements.userProfileBadge.classList.remove('hidden');
    elements.userNameLabel.textContent = state.user.name || 'Member';
    elements.userAvatarLetter.textContent = (state.user.name || 'U')[0].toUpperCase();
  } else {
    elements.signUpBtn.classList.remove('hidden');
    elements.logInBtn.classList.remove('hidden');
    elements.userProfileBadge.classList.add('hidden');
  }
}

// =========================================================
// Event Listeners
// =========================================================
function setupEventListeners() {
  // Logo Click
  elements.homeLogoBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (window.location.hash.startsWith('#actor/') || window.location.hash === '#my-streamfinder') returnToCatalog();
    resetAllFilters();
  });

  elements.navDashboardBtn.addEventListener('click', () => openDashboard());

  elements.dashboardPage.addEventListener('click', event => {
    const openButton = event.target.closest('[data-dashboard-open]');
    if (openButton) {
      const [type, id] = openButton.dataset.dashboardOpen.split(':');
      openDetailsModal(type, id);
      return;
    }
    if (event.target.closest('#clearHistoryBtn')) {
      state.recentHistory = [];
      state.dashboardRecommendationsCache.clear();
      savePersonalData();
      renderPersonalDashboard();
      return;
    }
    const removeWatchlistButton = event.target.closest('[data-remove-watchlist]');
    if (removeWatchlistButton) {
      const item = state.watchlist.find(entry => String(entry.id) === removeWatchlistButton.dataset.removeWatchlist && entry.showType === removeWatchlistButton.dataset.removeType);
      if (item) toggleWatchlist(item);
      return;
    }
    const removeRatingButton = event.target.closest('[data-remove-rating]');
    if (removeRatingButton) {
      state.userRatings = state.userRatings.filter(item => String(item.id) !== removeRatingButton.dataset.removeRating || item.showType !== removeRatingButton.dataset.removeType);
      savePersonalData();
      state.dashboardRecommendationsCache.clear();
      renderPersonalDashboard();
    }
  });

  elements.dashboardPage.addEventListener('change', event => {
    if (event.target.id === 'dashboardWatchlistSort') {
      state.watchlistSort = event.target.value;
      renderPersonalDashboard();
      return;
    }
    const categorySelect = event.target.closest('[data-watchlist-category]');
    if (categorySelect) {
      const item = state.watchlist.find(entry => String(entry.id) === categorySelect.dataset.watchlistCategory && entry.showType === categorySelect.dataset.watchlistType);
      if (item) {
        item.category = categorySelect.value;
        localStorage.setItem('motn_watchlist', JSON.stringify(state.watchlist));
      }
      return;
    }
    const ratingSelect = event.target.closest('[data-personal-rating]');
    if (ratingSelect) {
      const item = state.userRatings.find(entry => String(entry.id) === ratingSelect.dataset.personalRating && entry.showType === ratingSelect.dataset.ratingType);
      if (item) savePersonalRating(item, ratingSelect.value);
    }
  });

  elements.actorPage.addEventListener('click', (event) => {
    const backButton = event.target.closest('[data-actor-back]');
    if (backButton) {
      returnToCatalog();
      return;
    }
    const movieButton = event.target.closest('[data-movie-id]');
    if (movieButton) openDetailsModal('movie', movieButton.dataset.movieId);
  });

  elements.actorPage.addEventListener('change', (event) => {
    const filter = event.target.closest('[data-actor-filter]');
    if (!filter) return;
    state.actorFilters[filter.dataset.actorFilter] = filter.value;
    renderActorPage();
  });

  elements.detailsContent.addEventListener('click', (event) => {
    const actorButton = event.target.closest('[data-actor-id]');
    if (!actorButton) return;
    closeModal(elements.detailsModal);
    loadActorPage(actorButton.dataset.actorId);
  });

  window.addEventListener('popstate', syncRouteFromLocation);
  window.addEventListener('hashchange', syncRouteFromLocation);

  // Search Input
  elements.searchInput.addEventListener('input', (e) => {
    const val = e.target.value;
    elements.clearSearchBtn.classList.toggle('hidden', !val);

    clearTimeout(state.searchDebounceTimer);
    state.searchDebounceTimer = setTimeout(() => {
      state.searchQuery = val;
      refreshCatalog();
    }, 350);
  });

  elements.clearSearchBtn.addEventListener('click', () => {
    elements.searchInput.value = '';
    elements.clearSearchBtn.classList.add('hidden');
    state.searchQuery = '';
    refreshCatalog();
  });

  elements.categoryFilters.addEventListener('click', (event) => {
    const button = event.target.closest('[data-category]');
    if (!button || button.disabled) return;
    const category = button.dataset.category;
    if (category === 'free' || category === 'rent-buy') {
      state.selectedCategories.delete(category === 'free' ? 'rent-buy' : 'free');
    }
    if (category === 'new-releases' || category === 'upcoming') {
      state.selectedCategories.delete(category === 'new-releases' ? 'upcoming' : 'new-releases');
    }
    if (state.selectedCategories.has(category)) state.selectedCategories.delete(category);
    else state.selectedCategories.add(category);
    renderCategoryFilters();
    refreshCatalog();
  });

  elements.filterLanguage.addEventListener('change', () => {
    state.currentLanguage = elements.filterLanguage.value;
    refreshCatalog();
  });
  elements.filterYear.addEventListener('change', () => {
    state.currentYear = elements.filterYear.value;
    refreshCatalog();
  });
  elements.filterRuntime.addEventListener('change', () => {
    state.currentRuntime = elements.filterRuntime.value;
    refreshCatalog();
  });

  // Type Dropdown
  setupDropdown(elements.dropdownType, elements.typeTrigger, (val, text) => {
    state.currentType = val;
    elements.selectedTypeText.textContent = text;
    refreshCatalog();
  });

  // Rating Dropdown
  setupDropdown(elements.dropdownRating, elements.ratingTrigger, (val, text) => {
    state.currentRating = val;
    elements.selectedRatingText.textContent = text;
    refreshCatalog();
  });

  // Genre Dropdown
  setupDropdown(elements.dropdownGenre, elements.genreTrigger, (val, text, item) => {
    state.currentGenre = val;
    state.currentGenreIsKeyword = item.dataset.isKeyword === 'true';
    elements.selectedGenreText.textContent = text;
    refreshCatalog();
  });

  // Country Picker Modal
  elements.countryPickerBtn.addEventListener('click', () => {
    renderCountryPickerGrid();
    openModal(elements.countryModal);
  });
  elements.closeCountryBtn.addEventListener('click', () => closeModal(elements.countryModal));
  elements.countryModal.querySelector('.modal-backdrop-blur').addEventListener('click', () => closeModal(elements.countryModal));
  elements.countrySearchInput.addEventListener('input', (e) => {
    renderCountryPickerGrid(e.target.value);
  });

  // Surprise Me
  elements.surpriseMeBtn.addEventListener('click', () => {
    populateSurpriseSelectors();
    hideSurpriseResult();
    hideSurpriseStatus();
    openModal(elements.surpriseModal);
  });
  elements.closeSurpriseBtn.addEventListener('click', () => closeModal(elements.surpriseModal));
  elements.surpriseModal.querySelector('.modal-backdrop-blur').addEventListener('click', () => closeModal(elements.surpriseModal));
  elements.runSurpriseBtn.addEventListener('click', runSurpriseSearch);
  elements.resetSurpriseBtn.addEventListener('click', () => {
    elements.surpriseGenre.value = '';
    elements.surpriseMood.value = '';
    elements.surpriseLanguage.value = '';
    elements.surpriseCountry.value = state.currentCountry;
    elements.surpriseService.value = '';
    elements.surpriseTag.value = '';
    elements.surpriseReleaseFrom.value = '';
    elements.surpriseReleaseTo.value = '';
    elements.surpriseMinRating.value = '';
    elements.surpriseMaxRuntime.value = '';
    hideSurpriseStatus();
    hideSurpriseResult();
  });

  // Details Modal Close
  const closeDetails = () => {
    closeModal(elements.detailsModal);
    if (!elements.dashboardPage.classList.contains('hidden')) renderPersonalDashboard();
  };
  elements.closeDetailsBtn.addEventListener('click', closeDetails);
  elements.detailsModal.querySelector('.modal-backdrop-blur').addEventListener('click', closeDetails);

  // Video Modal Close
  elements.closeVideoBtn.addEventListener('click', () => {
    elements.videoContainer.innerHTML = '';
    closeModal(elements.videoModal);
  });
  elements.videoModal.querySelector('.modal-backdrop-blur').addEventListener('click', () => {
    elements.videoContainer.innerHTML = '';
    closeModal(elements.videoModal);
  });

  // Watchlist Drawer
  elements.navWatchlistBtn.addEventListener('click', () => {
    renderWatchlistDrawer();
    elements.watchlistDrawer.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  });
  elements.closeWatchlistBtn.addEventListener('click', () => closeModal(elements.watchlistDrawer));
  elements.closeWatchlistBackdrop.addEventListener('click', () => closeModal(elements.watchlistDrawer));

  // About Modal
  elements.navAboutBtn.addEventListener('click', () => openModal(elements.aboutModal));
  elements.closeAboutBtn.addEventListener('click', () => closeModal(elements.aboutModal));
  elements.aboutModal.querySelector('.modal-backdrop-blur').addEventListener('click', () => closeModal(elements.aboutModal));
  document.getElementById('footerAboutLink').addEventListener('click', (e) => {
    e.preventDefault();
    openModal(elements.aboutModal);
  });

  // API Modal
  elements.navApiBtn.addEventListener('click', () => openModal(elements.apiModal));
  elements.apiStatusBtn.addEventListener('click', () => openModal(elements.apiModal));
  elements.closeApiBtn.addEventListener('click', () => closeModal(elements.apiModal));
  elements.apiModal.querySelector('.modal-backdrop-blur').addEventListener('click', () => closeModal(elements.apiModal));
  document.getElementById('footerSettingsLink').addEventListener('click', (e) => {
    e.preventDefault();
    openModal(elements.apiModal);
  });
  document.getElementById('footerApiDocsLink').addEventListener('click', (e) => {
    e.preventDefault();
    openModal(elements.apiModal);
  });

  // Save API Keys Form
  elements.saveKeysBtn.addEventListener('click', async () => {
    const tmdbKey = elements.inputTmdbKey.value.trim();
    const motnKey = elements.inputMotnKey.value.trim();

    if (!tmdbKey && !motnKey) {
      showToast('Please enter an API key to update.');
      return;
    }

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tmdbApiKey: tmdbKey || undefined,
          streamingAvailabilityApiKey: motnKey || undefined
        })
      });
      const data = await res.json();
      if (data.success) {
        elements.saveKeysStatus.textContent = 'Keys updated successfully!';
        elements.saveKeysStatus.className = 'save-status success';
        showToast('API Keys saved! Reloading catalog...');
        await loadAppConfig();
        refreshCatalog();
        setTimeout(() => closeModal(elements.apiModal), 1000);
      }
    } catch (err) {
      console.error('Failed to update keys:', err);
      showToast('Error updating keys');
    }
  });

  // Catalogs Nav Modal or Filter
  elements.navCatalogsBtn.addEventListener('click', () => {
    // Scroll smoothly to the filter bar
    elements.servicesList.scrollIntoView({ behavior: 'smooth' });
    showToast('Select any streaming service in the filter bar!');
  });

  // Footer Catalog links
  document.querySelectorAll('[data-catalog]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const cat = link.dataset.catalog;
      state.selectedServices.clear();
      state.selectedServices.add(cat);
      renderServicesBar();
      refreshCatalog();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });

  // Auth Modals
  elements.signUpBtn.addEventListener('click', () => {
    document.getElementById('authModalTitle').innerHTML = '<i class="fa-solid fa-user-plus"></i> Sign Up';
    openModal(elements.authModal);
  });

  elements.logInBtn.addEventListener('click', () => {
    document.getElementById('authModalTitle').innerHTML = '<i class="fa-solid fa-user-circle"></i> Log In';
    openModal(elements.authModal);
  });

  elements.closeAuthBtn.addEventListener('click', () => closeModal(elements.authModal));
  elements.authModal.querySelector('.modal-backdrop-blur').addEventListener('click', () => closeModal(elements.authModal));

  elements.authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = elements.authEmail.value;
    const name = email.split('@')[0];
    state.user = { email, name };
    localStorage.setItem('motn_user', JSON.stringify(state.user));
    checkUserSession();
    closeModal(elements.authModal);
    if (state.currentDetailItem) renderMyMovieReviewEditor(state.currentDetailItem);
    showToast(`Welcome back, ${name}!`);
  });

  elements.logoutBtn.addEventListener('click', () => {
    state.user = null;
    localStorage.removeItem('motn_user');
    checkUserSession();
    if (state.currentDetailItem) renderMyMovieReviewEditor(state.currentDetailItem);
    showToast('Logged out successfully');
  });

  // Reset Filters Button
  elements.resetFiltersBtn.addEventListener('click', resetAllFilters);

  // Load More Button
  elements.loadMoreBtn.addEventListener('click', () => {
    if (state.page < state.totalPages) {
      if (state.searchQuery) {
        performSearch(state.page + 1);
      } else {
        performDiscover(state.page + 1);
      }
    }
  });

  // Retry Button
  elements.retryBtn.addEventListener('click', refreshCatalog);

  // Close Modals on Escape
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeDetails();
      closeModal(elements.countryModal);
      closeModal(elements.surpriseModal);
      closeModal(elements.apiModal);
      closeModal(elements.aboutModal);
      closeModal(elements.authModal);
      closeModal(elements.watchlistDrawer);
      closeModal(elements.videoModal);
    }
  });
}

// Helper: Setup Custom Dropdown
function setupDropdown(dropdownEl, triggerEl, onSelect) {
  triggerEl.addEventListener('click', (e) => {
    e.stopPropagation();
    // Close other dropdowns
    document.querySelectorAll('.custom-dropdown').forEach(d => {
      if (d !== dropdownEl) d.classList.remove('open');
    });
    dropdownEl.classList.toggle('open');
  });

  dropdownEl.querySelectorAll('.dropdown-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdownEl.querySelectorAll('.dropdown-item').forEach(el => el.classList.remove('active'));
      item.classList.add('active');
      dropdownEl.classList.remove('open');
      const val = item.dataset.value;
      const text = item.textContent.trim();
      onSelect(val, text, item);
    });
  });

  // Close on outside click
  document.addEventListener('click', () => {
    dropdownEl.classList.remove('open');
  });
}

// Kickoff
document.addEventListener('DOMContentLoaded', init);
