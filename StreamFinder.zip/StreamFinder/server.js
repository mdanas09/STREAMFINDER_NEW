const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API Keys
let TMDB_API_KEY = process.env.TMDB_API_KEY || '37d909951f4db42c0be79d6f27512b58';
let STREAMING_AVAILABILITY_API_KEY = process.env.STREAMING_AVAILABILITY_API_KEY || 'motn-key-v4-88FkawwqSCLfDH0nbCORLkV1BEpdXMF6';

// TMDB Base URL: use api.tmdb.org to avoid regional ISP blocks on api.themoviedb.org
const TMDB_BASE_URL = 'https://api.tmdb.org/3';
const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p';

// Service Mappings to TMDB Watch Provider IDs
const SERVICE_MAP = {
  netflix: { name: 'Netflix', tmdbId: 8, logo: 'https://media.movieofthenight.com/services/netflix/logo-light-theme.svg' },
  prime: { name: 'Prime Video', tmdbId: 119, altTmdbId: 9, logo: 'https://media.movieofthenight.com/services/prime/logo-light-theme.svg' },
  disney: { name: 'Disney+', tmdbId: 337, logo: 'https://media.movieofthenight.com/services/disney/logo-light-theme.svg' },
  hbo: { name: 'HBO Max', tmdbId: 1899, altTmdbId: 384, logo: 'https://media.movieofthenight.com/services/hbo/logo-light-theme.svg' },
  apple: { name: 'Apple TV', tmdbId: 350, altTmdbId: 2, logo: 'https://media.movieofthenight.com/services/apple/logo-light-theme.svg' },
  iplayer: { name: 'BBC iPlayer', tmdbId: 38, logo: 'https://media.movieofthenight.com/services/iplayer/logo-light-theme.svg' },
  itvx: { name: 'ITVX', tmdbId: 41, logo: 'https://media.movieofthenight.com/services/itvx/logo-light-theme.svg' },
  paramount: { name: 'Paramount+', tmdbId: 531, logo: 'https://media.movieofthenight.com/services/paramount/logo-light-theme.svg' },
  mubi: { name: 'MUBI', tmdbId: 11, logo: 'https://media.movieofthenight.com/services/mubi/logo-light-theme.svg' },
  channel4: { name: 'Channel 4', tmdbId: 103, logo: 'https://media.movieofthenight.com/services/all4/logo-light-theme.svg' },
  curiosity: { name: 'Curiosity Stream', tmdbId: 190, logo: 'https://media.movieofthenight.com/services/curiosity/logo-light-theme.svg' },
  discovery: { name: 'Discovery+', tmdbId: 582, altTmdbId: 524, logo: 'https://media.movieofthenight.com/services/discovery/logo-light-theme.svg' },
  plutotv: { name: 'Pluto TV', tmdbId: 300, logo: 'https://media.movieofthenight.com/services/plutotv/logo-light-theme.svg' },
  hulu: { name: 'Hulu', tmdbId: 15, logo: 'https://media.movieofthenight.com/services/hulu/logo-light-theme.svg' },
  peacock: { name: 'Peacock', tmdbId: 386, altTmdbId: 387, logo: 'https://media.movieofthenight.com/services/peacock/logo-light-theme.svg' },
  zee5: { name: 'Zee5', tmdbId: 232, logo: 'https://media.movieofthenight.com/services/zee5/logo-light-theme.svg' }
};

// Supported Countries
const COUNTRIES = [
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'IN', name: 'India', flag: '🇮🇳' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪' },
  { code: 'FR', name: 'France', flag: '🇫🇷' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱' },
  { code: 'SE', name: 'Sweden', flag: '🇸🇪' },
  { code: 'AR', name: 'Argentina', flag: '🇦🇷' }
];

// Simple in-memory Cache (5 min TTL)
const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getCached(key) {
  const item = cache.get(key);
  if (!item) return null;
  if (Date.now() - item.time > CACHE_TTL) {
    cache.delete(key);
    return null;
  }
  return item.data;
}

function setCache(key, data) {
  if (cache.size > 500) {
    const firstKey = cache.keys().next().value;
    cache.delete(firstKey);
  }
  cache.set(key, { time: Date.now(), data });
}

// Helper fetch with timeout
async function fetchWithTimeout(url, options = {}, timeoutMs = 8000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return res;
  } catch (err) {
    clearTimeout(id);
    throw err;
  }
}

// Format TMDB show/movie into STREAMFINDER card model
function formatShowItem(item, type = 'movie') {
  const isMovie = type === 'movie' || item.title !== undefined;
  const showType = isMovie ? 'movie' : 'tv';
  const id = item.id;
  const title = item.title || item.name || 'Untitled';
  const releaseDate = item.release_date || item.first_air_date || '';
  const releaseYear = releaseDate ? new Date(releaseDate).getFullYear() : '';
  const rating = item.vote_average ? Number(item.vote_average.toFixed(1)) : 0;
  
  // High quality images
  const backdropUrl = item.backdrop_path 
    ? `${TMDB_IMAGE_BASE}/w780${item.backdrop_path}` 
    : (item.poster_path ? `${TMDB_IMAGE_BASE}/w780${item.poster_path}` : null);
  const posterUrl = item.poster_path 
    ? `${TMDB_IMAGE_BASE}/w500${item.poster_path}` 
    : null;

  return {
    id,
    itemType: 'show',
    showType,
    title,
    originalTitle: item.original_title || item.original_name || title,
    originalLanguage: item.original_language || 'en',
    overview: item.overview || '',
    releaseYear,
    rating,
    runtime: item.runtime || null,
    voteCount: item.vote_count || 0,
    popularity: item.popularity || 0,
    backdropUrl,
    posterUrl,
    genreIds: item.genre_ids || [],
    isRecentlyAdded: item.popularity > 80 || (item.release_date && new Date(item.release_date) > new Date(Date.now() - 180 * 24 * 60 * 60 * 1000))
  };
}

// TMDB Genre Map
const GENRE_MAP = {
  28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime',
  99: 'Documentary', 18: 'Drama', 10751: 'Family', 14: 'Fantasy', 36: 'History',
  27: 'Horror', 10402: 'Music', 9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi',
  10770: 'TV Movie', 53: 'Thriller', 10752: 'War', 37: 'Western',
  10759: 'Action & Adventure', 10762: 'Kids', 10763: 'News', 10764: 'Reality',
  10765: 'Sci-Fi & Fantasy', 10766: 'Soap', 10767: 'Talk', 10768: 'War & Politics'
};

// --- ROUTES ---

// 1. Get Supported Services
app.get('/api/services', (req, res) => {
  res.json({
    services: Object.entries(SERVICE_MAP).map(([id, info]) => ({
      id,
      name: info.name,
      tmdbId: info.tmdbId,
      logo: info.logo
    }))
  });
});

// 2. Get Supported Countries
app.get('/api/countries', (req, res) => {
  res.json({ countries: COUNTRIES });
});

// 3. Get API Key Status & Config
app.get('/api/config', (req, res) => {
  res.json({
    tmdbConfigured: !!TMDB_API_KEY,
    motnConfigured: !!STREAMING_AVAILABILITY_API_KEY,
    tmdbKeyPreview: TMDB_API_KEY ? `${TMDB_API_KEY.slice(0, 4)}...${TMDB_API_KEY.slice(-4)}` : null,
    motnKeyPreview: STREAMING_AVAILABILITY_API_KEY ? `${STREAMING_AVAILABILITY_API_KEY.slice(0, 8)}...` : null
  });
});

// 4. Update API Keys
app.post('/api/config', (req, res) => {
  const { tmdbApiKey, streamingAvailabilityApiKey } = req.body;
  if (tmdbApiKey) TMDB_API_KEY = tmdbApiKey.trim();
  if (streamingAvailabilityApiKey) STREAMING_AVAILABILITY_API_KEY = streamingAvailabilityApiKey.trim();
  cache.clear();
  res.json({ success: true, message: 'API keys updated successfully!' });
});

// 5. Browse: Curated Rows for Homepage
app.get('/api/browse', async (req, res) => {
  const country = (req.query.country || 'GB').toUpperCase();
  const service = req.query.service || null;
  const cacheKey = `browse_${country}_${service || 'all'}`;
  
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    let watchProviderParam = '';
    if (service && SERVICE_MAP[service]) {
      const s = SERVICE_MAP[service];
      watchProviderParam = `&watch_region=${country}&with_watch_providers=${s.tmdbId}${s.altTmdbId ? '|' + s.altTmdbId : ''}`;
    }

    // Row 1: Serial Killer Movies (Crime + Thriller, dark themes)
    const serialKillerUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}&with_genres=80,53&sort_by=vote_count.desc&vote_average.gte=6.0&page=1${watchProviderParam}`;

    // Row 2: Most Popular Sport Movies (Keyword 6075 sport)
    const sportMoviesUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}&with_keywords=6075&sort_by=popularity.desc&page=1${watchProviderParam}`;

    // Row 3: Quirky Comedy Series (TV, Genre 35)
    const comedySeriesUrl = `${TMDB_BASE_URL}/discover/tv?api_key=${TMDB_API_KEY}&with_genres=35&sort_by=popularity.desc&page=1${watchProviderParam}`;

    // Row 4: Trending This Week (Movies & Series)
    const trendingMoviesUrl = `${TMDB_BASE_URL}/trending/movie/week?api_key=${TMDB_API_KEY}&page=1`;

    // Row 5: Mindbending Sci-Fi Thrillers (Genre 878)
    const sciFiUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}&with_genres=878,53&sort_by=popularity.desc&vote_average.gte=6.5&page=1${watchProviderParam}`;

    // Row 6: High-Octane Action (Genre 28)
    const actionUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}&with_genres=28&sort_by=popularity.desc&vote_average.gte=6.5&page=1${watchProviderParam}`;

    // Row 7: Critically Acclaimed Masterpieces (Rating 8.0+)
    const topRatedUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}&vote_average.gte=8.0&vote_count.gte=1000&sort_by=vote_average.desc&page=1${watchProviderParam}`;

    const [
      resSerialKiller,
      resSport,
      resComedy,
      resTrending,
      resSciFi,
      resAction,
      resTopRated
    ] = await Promise.all([
      fetchWithTimeout(serialKillerUrl).then(r => r.json()).catch(() => ({ results: [] })),
      fetchWithTimeout(sportMoviesUrl).then(r => r.json()).catch(() => ({ results: [] })),
      fetchWithTimeout(comedySeriesUrl).then(r => r.json()).catch(() => ({ results: [] })),
      fetchWithTimeout(trendingMoviesUrl).then(r => r.json()).catch(() => ({ results: [] })),
      fetchWithTimeout(sciFiUrl).then(r => r.json()).catch(() => ({ results: [] })),
      fetchWithTimeout(actionUrl).then(r => r.json()).catch(() => ({ results: [] })),
      fetchWithTimeout(topRatedUrl).then(r => r.json()).catch(() => ({ results: [] }))
    ]);

    const result = {
      country,
      service,
      rows: [
        {
          id: 'serial-killer',
          title: 'Serial Killer Movies',
          subtitle: 'Dark thrillers, psychological investigations, and true crime',
          type: 'movie',
          items: (resSerialKiller.results || []).slice(0, 15).map(item => formatShowItem(item, 'movie'))
        },
        {
          id: 'sport-movies',
          title: 'Most Popular Sport Movies',
          subtitle: 'Triumph, adrenaline, and true athletic spirit',
          type: 'movie',
          items: (resSport.results || []).slice(0, 15).map(item => formatShowItem(item, 'movie'))
        },
        {
          id: 'comedy-series',
          title: 'Quirky Comedy Series',
          subtitle: 'Laugh-out-loud television to binge-watch',
          type: 'tv',
          items: (resComedy.results || []).slice(0, 15).map(item => formatShowItem(item, 'tv'))
        },
        {
          id: 'trending-week',
          title: 'Trending on Streaming',
          subtitle: 'The hottest titles everyone is talking about right now',
          type: 'movie',
          items: (resTrending.results || []).slice(0, 15).map(item => formatShowItem(item, 'movie'))
        },
        {
          id: 'sci-fi-thrillers',
          title: 'Sci-Fi Mindbenders',
          subtitle: 'Futuristic worlds, time paradoxes, and alien encounters',
          type: 'movie',
          items: (resSciFi.results || []).slice(0, 15).map(item => formatShowItem(item, 'movie'))
        },
        {
          id: 'action-hits',
          title: 'High-Octane Action Blockbusters',
          subtitle: 'Explosive stunts, heart-pounding chases, and martial arts',
          type: 'movie',
          items: (resAction.results || []).slice(0, 15).map(item => formatShowItem(item, 'movie'))
        },
        {
          id: 'top-rated',
          title: 'Critically Acclaimed Masterpieces',
          subtitle: 'Highest rated cinematic gems rated 8.0 and above',
          type: 'movie',
          items: (resTopRated.results || []).slice(0, 15).map(item => formatShowItem(item, 'movie'))
        }
      ]
    };

    setCache(cacheKey, result);
    res.json(result);
  } catch (err) {
    console.error('Browse error:', err);
    res.status(500).json({ error: 'Failed to fetch browse lists', message: err.message });
  }
});

// 6. Discover & Filter Catalog
app.get('/api/discover', async (req, res) => {
  const {
    type = 'all', // 'all', 'movie', 'tv'
    service,
    country = 'GB',
    genre,
    rating,
    categories = '',
    language,
    year,
    runtime,
    sort = 'popularity.desc',
    page = 1
  } = req.query;

  const categorySet = new Set(String(categories).split(',').filter(Boolean));
  const monetization = categorySet.has('free') ? 'free|ads' : categorySet.has('rent-buy') ? 'rent|buy' : '';
  const cacheKey = `discover_${type}_${service || 'all'}_${country}_${genre || 'all'}_${rating || 'all'}_${categories}_${language || 'all'}_${year || 'all'}_${runtime || 'all'}_${sort}_${page}`;
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const regionCode = country.toUpperCase();
    let providerQuery = service || monetization ? `&watch_region=${regionCode}` : '';
    if (service) {
      const services = service.split(',');
      const providerIds = [];
      services.forEach(s => {
        const info = SERVICE_MAP[s.trim().toLowerCase()];
        if (info) {
          providerIds.push(info.tmdbId);
          if (info.altTmdbId) providerIds.push(info.altTmdbId);
        }
      });
      if (providerIds.length > 0) {
        providerQuery += `&with_watch_providers=${providerIds.join('|')}`;
      }
    }

    let genreQuery = genre ? `&with_genres=${genre}` : '';
    const minimumRating = Math.max(Number(rating) || 0, categorySet.has('highly-rated') ? 8 : 0, categorySet.has('hidden-gems') ? 7 : 0);
    let ratingQuery = minimumRating ? `&vote_average.gte=${minimumRating}` : '';
    const languageQuery = language ? `&with_original_language=${encodeURIComponent(language)}` : '';
    const runtimeQuery = runtime ? `&with_runtime.lte=${encodeURIComponent(runtime)}` : '';
    const monetizationQuery = monetization ? `&with_watch_monetization_types=${encodeURIComponent(monetization)}` : '';
    const hiddenGemsQuery = categorySet.has('hidden-gems') ? '&vote_count.gte=100&popularity.lte=50' : '';
    const releaseStart = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const today = new Date().toISOString().slice(0, 10);
    const upcomingEndDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

    const getTypeFilters = mediaType => {
      const isMovie = mediaType === 'movie';
      const yearQuery = year ? `&${isMovie ? 'primary_release_year' : 'first_air_date_year'}=${encodeURIComponent(year)}` : '';
      let dateQuery = '';
      if (categorySet.has('new-releases')) {
        dateQuery += `&${isMovie ? 'primary_release_date' : 'first_air_date'}.gte=${releaseStart}`;
        dateQuery += `&${isMovie ? 'primary_release_date' : 'first_air_date'}.lte=${today}`;
      }
      if (categorySet.has('upcoming')) {
        dateQuery += `&${isMovie ? 'primary_release_date' : 'first_air_date'}.gte=${today}`;
        dateQuery += `&${isMovie ? 'primary_release_date' : 'first_air_date'}.lte=${upcomingEndDate}`;
      }
      const sortBy = categorySet.has('upcoming')
        ? `${isMovie ? 'primary_release_date' : 'first_air_date'}.asc`
        : categorySet.has('new-releases')
          ? `${isMovie ? 'primary_release_date' : 'first_air_date'}.desc`
          : categorySet.has('hidden-gems')
            ? 'vote_average.desc'
            : categorySet.has('trending')
              ? 'popularity.desc'
              : sort;

      return `&sort_by=${sortBy}${yearQuery}${dateQuery}`;
    };

    const commonFilters = `${genreQuery}${ratingQuery}${languageQuery}${runtimeQuery}${monetizationQuery}${hiddenGemsQuery}`;

    let results = [];
    let totalPages = 1;

    if (type === 'tv') {
      const tvUrl = `${TMDB_BASE_URL}/discover/tv?api_key=${TMDB_API_KEY}${getTypeFilters('tv')}${commonFilters}${providerQuery}&page=${page}`;
      const tvRes = await fetchWithTimeout(tvUrl).then(r => r.json());
      results = (tvRes.results || []).map(item => formatShowItem(item, 'tv'));
      totalPages = tvRes.total_pages || 1;
    } else if (type === 'movie') {
      const movieUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}${getTypeFilters('movie')}${commonFilters}${providerQuery}&page=${page}`;
      const movieRes = await fetchWithTimeout(movieUrl).then(r => r.json());
      results = (movieRes.results || []).map(item => formatShowItem(item, 'movie'));
      totalPages = movieRes.total_pages || 1;
    } else {
      // Both movies & tv: fetch half and half or movies page 1
      const movieUrl = `${TMDB_BASE_URL}/discover/movie?api_key=${TMDB_API_KEY}${getTypeFilters('movie')}${commonFilters}${providerQuery}&page=${page}`;
      const tvUrl = `${TMDB_BASE_URL}/discover/tv?api_key=${TMDB_API_KEY}${getTypeFilters('tv')}${commonFilters}${providerQuery}&page=${page}`;
      const [movieRes, tvRes] = await Promise.all([
        fetchWithTimeout(movieUrl).then(r => r.json()).catch(() => ({ results: [] })),
        fetchWithTimeout(tvUrl).then(r => r.json()).catch(() => ({ results: [] }))
      ]);

      const formattedMovies = (movieRes.results || []).map(item => formatShowItem(item, 'movie'));
      const formattedTv = (tvRes.results || []).map(item => formatShowItem(item, 'tv'));
      
      // Interleave results
      const combined = [];
      const maxLen = Math.max(formattedMovies.length, formattedTv.length);
      for (let i = 0; i < maxLen; i++) {
        if (formattedMovies[i]) combined.push(formattedMovies[i]);
        if (formattedTv[i]) combined.push(formattedTv[i]);
      }
      results = combined;
      totalPages = Math.max(movieRes.total_pages || 1, tvRes.total_pages || 1);
    }

    const output = {
      page: Number(page),
      totalPages,
      count: results.length,
      results
    };

    setCache(cacheKey, output);
    res.json(output);
  } catch (err) {
    console.error('Discover error:', err);
    res.status(500).json({ error: 'Failed to discover titles', message: err.message });
  }
});

// 7. Instant Search
app.get('/api/search', async (req, res) => {
  const query = req.query.q || '';
  const type = req.query.type || 'all';
  const page = req.query.page || 1;

  if (!query.trim()) {
    return res.json({ results: [], count: 0 });
  }

  const cacheKey = `search_${type}_${query.trim().toLowerCase()}_${page}`;
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    let endpoint = `${TMDB_BASE_URL}/search/multi?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&page=${page}`;
    if (type === 'movie') endpoint = `${TMDB_BASE_URL}/search/movie?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&page=${page}`;
    if (type === 'tv') endpoint = `${TMDB_BASE_URL}/search/tv?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&page=${page}`;

    const data = await fetchWithTimeout(endpoint).then(r => r.json());
    const filtered = (data.results || [])
      .filter(item => item.media_type !== 'person' && (item.backdrop_path || item.poster_path))
      .map(item => formatShowItem(item, item.media_type || type));

    const output = {
      query,
      page: Number(page),
      totalPages: data.total_pages || 1,
      count: filtered.length,
      results: filtered
    };

    setCache(cacheKey, output);
    res.json(output);
  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Search failed', message: err.message });
  }
});

// 8. Detailed Show Info with Streaming Availability
app.get('/api/reviews/:type/:id', async (req, res) => {
  const { id } = req.params;
  const type = req.params.type === 'tv' ? 'tv' : 'movie';
  const page = Math.max(1, Number(req.query.page) || 1);
  const cacheKey = `reviews_${type}_${id}_${page}`;
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const endpoint = `${TMDB_BASE_URL}/${type}/${id}/reviews?api_key=${TMDB_API_KEY}&page=${page}`;
    const data = await fetchWithTimeout(endpoint).then(response => response.json());
    if (data.status_code === 34) return res.status(404).json({ error: 'Title not found' });
    const response = {
      source: 'TMDB',
      page: Number(data.page) || page,
      totalPages: Number(data.total_pages) || 0,
      totalResults: Number(data.total_results) || 0,
      results: (data.results || []).map(review => ({
        id: review.id,
        author: review.author || review.author_details?.username || 'TMDB member',
        rating: typeof review.author_details?.rating === 'number' && Number.isFinite(review.author_details.rating)
          ? review.author_details.rating
          : null,
        content: review.content || '',
        createdAt: review.created_at || '',
        url: review.url || ''
      }))
    };
    setCache(cacheKey, response);
    res.json(response);
  } catch (err) {
    console.error('Reviews error:', err);
    res.status(500).json({ error: 'Failed to fetch reviews', message: err.message });
  }
});

app.get('/api/details/:type/:id', async (req, res) => {
  const { type, id } = req.params;
  const country = (req.query.country || 'GB').toUpperCase();
  const showType = type === 'tv' ? 'tv' : 'movie';

  const cacheKey = `details_${showType}_${id}_${country}`;
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const detailsUrl = `${TMDB_BASE_URL}/${showType}/${id}?api_key=${TMDB_API_KEY}&append_to_response=credits,videos,recommendations,watch/providers`;
    const data = await fetchWithTimeout(detailsUrl).then(r => r.json());

    if (data.status_code === 34 || !data.id) {
      return res.status(404).json({ error: 'Title not found' });
    }

    // Process Watch Providers for requested country
    const watchProvidersAll = data['watch/providers']?.results || {};
    const countryProviders = watchProvidersAll[country] || watchProvidersAll['US'] || watchProvidersAll['GB'] || {};

    const formatProviderList = (list = []) => {
      return list.map(p => ({
        id: p.provider_id,
        name: p.provider_name,
        logo: `${TMDB_IMAGE_BASE}/original${p.logo_path}`,
        displayPriority: p.display_priority
      }));
    };

    const titlePageLink = `https://www.themoviedb.org/${showType}/${id}`;
    const streamingOptions = {
      country: watchProvidersAll[country] ? country : Object.keys(watchProvidersAll)[0] || country,
      link: titlePageLink,
      stream: formatProviderList(countryProviders.flatrate),
      rent: formatProviderList(countryProviders.rent),
      buy: formatProviderList(countryProviders.buy),
      free: formatProviderList(countryProviders.free || countryProviders.ads),
      allCountriesAvailable: Object.keys(watchProvidersAll)
    };

    // Extract Trailer video if available
    let trailer = null;
    const videos = data.videos?.results || [];
    const officialTrailer = videos.find(v => v.site === 'YouTube' && v.type === 'Trailer');
    const anyTrailer = videos.find(v => v.site === 'YouTube');
    if (officialTrailer || anyTrailer) {
      const v = officialTrailer || anyTrailer;
      trailer = {
        key: v.key,
        name: v.name,
        youtubeUrl: `https://www.youtube.com/watch?v=${v.key}`,
        embedUrl: `https://www.youtube.com/embed/${v.key}`
      };
    }

    // Directors and Cast
    const credits = data.credits || {};
    const directors = (credits.crew || [])
      .filter(c => c.job === 'Director')
      .map(c => ({ id: c.id, name: c.name, profilePath: c.profile_path ? `${TMDB_IMAGE_BASE}/w185${c.profile_path}` : null }));

    const cast = (credits.cast || []).slice(0, 10).map(c => ({
      id: c.id,
      name: c.name,
      character: c.character,
      profilePath: c.profile_path ? `${TMDB_IMAGE_BASE}/w185${c.profile_path}` : null
    }));

    // Similar / Recommendations
    const recommendations = (data.recommendations?.results || []).slice(0, 8).map(item => formatShowItem(item, showType));

    const response = {
      id: data.id,
      imdbId: data.imdb_id,
      itemType: 'show',
      showType,
      title: data.title || data.name,
      originalTitle: data.original_title || data.original_name,
      originalLanguage: data.original_language || '',
      tagline: data.tagline || '',
      overview: data.overview || '',
      releaseDate: data.release_date || data.first_air_date,
      releaseYear: (data.release_date || data.first_air_date || '').split('-')[0],
      runtime: data.runtime || (data.episode_run_time ? data.episode_run_time[0] : null),
      seasonsCount: data.number_of_seasons,
      episodesCount: data.number_of_episodes,
      rating: data.vote_average ? Number(data.vote_average.toFixed(1)) : 0,
      voteCount: data.vote_count,
      genres: (data.genres || []).map(g => ({ id: g.id, name: g.name })),
      backdropUrl: data.backdrop_path ? `${TMDB_IMAGE_BASE}/w1280${data.backdrop_path}` : null,
      posterUrl: data.poster_path ? `${TMDB_IMAGE_BASE}/w500${data.poster_path}` : null,
      collection: data.belongs_to_collection ? {
        id: data.belongs_to_collection.id,
        name: data.belongs_to_collection.name
      } : null,
      streamingOptions,
      trailer,
      directors,
      cast,
      recommendations
    };

    setCache(cacheKey, response);
    res.json(response);
  } catch (err) {
    console.error('Details error:', err);
    res.status(500).json({ error: 'Failed to fetch details', message: err.message });
  }
});

app.get('/api/collections/:id', async (req, res) => {
  const { id } = req.params;
  const cacheKey = `collection_${id}`;
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const data = await fetchWithTimeout(`${TMDB_BASE_URL}/collection/${id}?api_key=${TMDB_API_KEY}`).then(r => r.json());
    if (!data.id || data.status_code === 34) return res.status(404).json({ error: 'Collection not found' });
    const response = {
      id: data.id,
      name: data.name,
      parts: (data.parts || []).map(part => ({
        ...formatShowItem(part, 'movie'),
        releaseDate: part.release_date || ''
      }))
    };
    setCache(cacheKey, response);
    res.json(response);
  } catch (err) {
    console.error('Collection error:', err);
    res.status(500).json({ error: 'Failed to fetch collection', message: err.message });
  }
});

// Actor profile with deduplicated acting credits and movie availability.
app.get('/api/actors/:id', async (req, res) => {
  const { id } = req.params;
  const country = (req.query.country || 'GB').toUpperCase();
  const cacheKey = `actor_${id}_${country}`;
  const cached = getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    const [person, movieCredits] = await Promise.all([
      fetchWithTimeout(`${TMDB_BASE_URL}/person/${id}?api_key=${TMDB_API_KEY}&append_to_response=external_ids`).then(r => r.json()),
      fetchWithTimeout(`${TMDB_BASE_URL}/person/${id}/movie_credits?api_key=${TMDB_API_KEY}`).then(r => r.json())
    ]);

    if (!person.id || person.status_code === 34) {
      return res.status(404).json({ error: 'Actor not found' });
    }

    const uniqueCredits = new Map();
    for (const credit of movieCredits.cast || []) {
      if (!credit.id || !credit.title) continue;
      const existing = uniqueCredits.get(credit.id);
      if (existing) {
        const characters = new Set([existing.character, credit.character].filter(Boolean));
        existing.character = Array.from(characters).join(' / ');
      } else {
        uniqueCredits.set(credit.id, { ...credit });
      }
    }

    const credits = Array.from(uniqueCredits.values());
    const movies = new Array(credits.length);
    let nextIndex = 0;
    const loadCreditDetails = async () => {
      while (nextIndex < credits.length) {
        const index = nextIndex++;
        const credit = credits[index];
        try {
          const details = await fetchWithTimeout(
            `${TMDB_BASE_URL}/movie/${credit.id}?api_key=${TMDB_API_KEY}&append_to_response=credits,watch/providers`
          ).then(r => r.json());
          const countryProviders = details['watch/providers']?.results?.[country] || {};
          const providers = [
            ...(countryProviders.flatrate || []),
            ...(countryProviders.rent || []),
            ...(countryProviders.buy || []),
            ...(countryProviders.free || countryProviders.ads || [])
          ];
          const uniqueProviders = Array.from(new Map(providers.map(provider => [provider.provider_id, {
            id: provider.provider_id,
            name: provider.provider_name,
            logo: provider.logo_path ? `${TMDB_IMAGE_BASE}/w92${provider.logo_path}` : null
          }])).values());
          const director = (details.credits?.crew || []).find(member => member.job === 'Director');

          movies[index] = {
            ...formatShowItem(credit, 'movie'),
            character: credit.character || '',
            genres: (details.genres || []).map(genre => ({ id: genre.id, name: genre.name })),
            productionCountries: (details.production_countries || []).map(countryInfo => countryInfo.iso_3166_1),
            director: director?.name || '',
            providers: uniqueProviders
          };
        } catch (error) {
          movies[index] = {
            ...formatShowItem(credit, 'movie'),
            character: credit.character || '',
            genres: (credit.genre_ids || []).map(genreId => ({ id: genreId, name: GENRE_MAP[genreId] || 'Other' })),
            productionCountries: [],
            director: '',
            providers: []
          };
        }
      }
    };

    await Promise.all(Array.from({ length: Math.min(8, credits.length) }, loadCreditDetails));

    const externalIds = person.external_ids || {};
    const socialLinks = [
      externalIds.imdb_id && { label: 'IMDb', url: `https://www.imdb.com/name/${externalIds.imdb_id}/` },
      externalIds.instagram_id && { label: 'Instagram', url: `https://www.instagram.com/${externalIds.instagram_id}/` },
      externalIds.twitter_id && { label: 'X', url: `https://x.com/${externalIds.twitter_id}` },
      externalIds.facebook_id && { label: 'Facebook', url: `https://www.facebook.com/${externalIds.facebook_id}` },
      person.homepage && { label: 'Official Website', url: person.homepage }
    ].filter(Boolean);

    const response = {
      id: person.id,
      name: person.name,
      profileUrl: person.profile_path ? `${TMDB_IMAGE_BASE}/h632${person.profile_path}` : null,
      knownForDepartment: person.known_for_department || '',
      biography: person.biography || '',
      birthday: person.birthday || '',
      placeOfBirth: person.place_of_birth || '',
      professions: Array.from(new Set([
        person.known_for_department,
        ...(movieCredits.crew || []).map(credit => credit.department)
      ].filter(Boolean))),
      popularity: Number.isFinite(person.popularity) ? person.popularity : null,
      socialLinks,
      knownFor: [...movies].sort((a, b) => b.popularity - a.popularity).slice(0, 6),
      movies
    };

    setCache(cacheKey, response);
    res.json(response);
  } catch (err) {
    console.error('Actor details error:', err);
    res.status(500).json({ error: 'Failed to fetch actor details', message: err.message });
  }
});

// Fallback to index.html for SPA routes
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🎬 STREAMFINDER - Localhost Server Running!`);
  console.log(`🌐 Local URL: http://localhost:${PORT}`);
  console.log(`🔑 TMDB API Key: ${TMDB_API_KEY ? 'Active' : 'Missing'}`);
  console.log(`🔑 Streaming Availability Key: ${STREAMING_AVAILABILITY_API_KEY ? 'Configured' : 'Missing'}`);
  console.log(`=======================================================`);
});
